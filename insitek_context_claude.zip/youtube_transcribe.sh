#!/usr/bin/env bash
set -euo pipefail

# ───────────── parameters ─────────────
URL="$1"
[ -z "$URL" ] && { echo "Usage: $0 <youtube-url>" >&2; exit 1; }

# ─────────── metadata (single yt-dl call) ───────────
echo "STAGE:Extracting metadata"
echo "PROGRESS:5"

# id | title | uploader | upload_date (YYYYMMDD)
IFS='|' read -r ID TITLE CHANNEL UPLOAD <<<"$(
  yt-dlp -s --print "%(id)s|%(title)s|%(uploader)s|%(upload_date)s" "$URL"
)"

BASE="yt_${ID}"           # common prefix
MP3="${BASE}.mp3"
TXT="${BASE}.txt"

UPLOAD_ISO=""
[[ $UPLOAD =~ ^[0-9]{8}$ ]] && UPLOAD_ISO="${UPLOAD:0:4}-${UPLOAD:4:2}-${UPLOAD:6:2}"

echo "PROGRESS:10"

# ─────────── download & transcribe ───────────
echo "STAGE:Downloading audio"
echo "PROGRESS:10"

# Download with better progress tracking
yt-dlp -f bestaudio --extract-audio --audio-format mp3 --audio-quality 0 \
       --force-overwrites -o "$MP3" \
       --progress \
       "$URL" 2>&1 | while IFS= read -r line; do
  # Look for download progress - yt-dlp outputs like "[download] 45.2% of 15.23MB"
  if [[ "$line" =~ \[download\].*([0-9]+(\.[0-9]+)?)% ]]; then
    download_pct="${BASH_REMATCH[1]}"
    # Convert to integer
    download_int=$(printf "%.0f" "$download_pct")
    # Map download progress (0-100%) to our progress range (10-30%)
    overall_pct=$((10 + (download_int * 20 / 100)))
    echo "PROGRESS:$overall_pct"
  fi
done

echo "PROGRESS:30"
echo "STAGE:Transcribing audio"

cd whisper.cpp
./build/bin/whisper-cli -m models/ggml-base.en.bin \
        -f "../$MP3" -otxt -of "../$BASE" 2>&1 | while IFS= read -r line; do
  # Look for whisper progress patterns
  if [[ "$line" =~ progress.*=.*([0-9]+)% ]]; then
    whisper_pct="${BASH_REMATCH[1]}"
    # Map whisper progress (0-100%) to our progress range (30-85%)
    overall_pct=$((30 + (whisper_pct * 55 / 100)))
    echo "PROGRESS:$overall_pct"
  elif [[ "$line" =~ \[.*\].*([0-9]+)% ]]; then
    whisper_pct="${BASH_REMATCH[1]}"
    overall_pct=$((30 + (whisper_pct * 55 / 100)))
    echo "PROGRESS:$overall_pct"
  fi
done
cd ..

echo "PROGRESS:90"
echo "STAGE:Saving to database"
echo "PROGRESS:95"

# ─────────── markers for Node ───────────
echo "FILE:${TXT}"          # path the server will read
echo "TITLE:${TITLE}"
echo "CHANNEL:${CHANNEL}"
echo "PUBLISH:${UPLOAD_ISO}"
echo "PROGRESS:100"
echo "♥ DONE"