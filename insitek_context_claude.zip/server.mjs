/* ===================================================================
   server.mjs  –  Express backend for Insitek.ai with Podcast Support
   =================================================================== */
   import express from "express";
   import cors    from "cors";
   import { exec, spawn } from "node:child_process";
   import fs      from "node:fs/promises";
   import { existsSync } from "node:fs";
   import path    from "node:path";
   import { fileURLToPath } from "node:url";
   import xml2js from "xml2js";
   import { promisify } from "util";
   import { PrismaClient } from '@prisma/client';
   import { WebSocketServer } from 'ws';
   import { createServer } from 'http';
   
   const execPromise = promisify(exec);
   const prisma = new PrismaClient();
   
   /* ----- meta helpers ---------------------------------------------- */
   console.log(">>> STARTING server.mjs from", import.meta.url);
   
   const __filename = fileURLToPath(import.meta.url);
   const __dirname  = path.dirname(__filename);
   
   const app  = express();
   const PORT = process.env.PORT || 3001;
   
   app.use(cors());
   app.use(express.json());
   
   // Create HTTP server and WebSocket server
   const server = createServer(app);
   const wss = new WebSocketServer({ server });
   
   // Store active WebSocket connections by import session ID
   const activeImports = new Map();
   
   wss.on('connection', (ws) => {
     console.log('WebSocket client connected');
     
     ws.on('message', (message) => {
       try {
         const data = JSON.parse(message);
         if (data.type === 'subscribe' && data.importId) {
           console.log(`Client subscribed to import ${data.importId}`);
           activeImports.set(data.importId, ws);
         }
       } catch (e) {
         console.error('Invalid WebSocket message:', e);
       }
     });
     
     ws.on('close', () => {
       console.log('WebSocket client disconnected');
       // Remove from active imports
       for (const [importId, socket] of activeImports.entries()) {
         if (socket === ws) {
           activeImports.delete(importId);
           break;
         }
       }
     });
   });
   
   // Helper function to send progress updates
   async function sendProgress(importId, stage, progress) {
     // Derive ImportJob.state based on stage text
     let derivedState = 'PROCESSING';
     if (stage === 'Completed') {
       derivedState = 'DONE';
     } else if (stage.toLowerCase().startsWith('error')) {
       derivedState = 'ERROR';
     }
   
     // Best-effort DB update (ignore if job doesn't exist)
     try {
       await prisma.importJob.update({
         where: { id: importId },
         data: {
           state: derivedState,
           progress
         }
       });
     } catch (e) {
       // Ignore not found errors – job may not have been created yet
     }
   
     // Broadcast to any subscribed WebSocket client
     const ws = activeImports.get(importId);
     if (ws && ws.readyState === 1) { // WebSocket.OPEN
       ws.send(JSON.stringify({
         type: 'progress',
         importId,
         stage,
         progress
       }));
     }
   }
   
   /* ==================================================================
      /api/transcripts - GET ALL TRANSCRIPTS
      ================================================================== */
   app.get("/api/transcripts", async (req, res) => {
     try {
       const transcripts = await prisma.transcript.findMany({
         orderBy: { importedAt: 'desc' },
         select: {
           id: true,
           title: true,
           channel: true,
           publishDate: true,
           importedAt: true,
           source: true
         }
       });
       res.json(transcripts);
     } catch (error) {
       console.error("Error fetching transcripts:", error);
       res.status(500).json({ error: "Failed to fetch transcripts" });
     }
   });
   
   /* ==================================================================
      /api/transcripts/:id - GET SINGLE TRANSCRIPT
      ================================================================== */
   app.get("/api/transcripts/:id", async (req, res) => {
     try {
       const transcript = await prisma.transcript.findUnique({
         where: { id: req.params.id }
       });
       
       if (!transcript) {
         return res.status(404).json({ error: "Transcript not found" });
       }
       
       res.json(transcript);
     } catch (error) {
       console.error("Error fetching transcript:", error);
       res.status(500).json({ error: "Failed to fetch transcript" });
     }
   });
   
   /* ==================================================================
      /api/transcripts/:id - DELETE TRANSCRIPT
      ================================================================== */
   app.delete("/api/transcripts/:id", async (req, res) => {
     try {
       await prisma.transcript.delete({
         where: { id: req.params.id }
       });
       res.json({ success: true });
     } catch (error) {
       if (error.code === 'P2025') {
         return res.status(404).json({ error: "Transcript not found" });
       }
       console.error("Error deleting transcript:", error);
       res.status(500).json({ error: "Failed to delete transcript" });
     }
   });
   
   /* ==================================================================
   /api/transcribe-youtube  – IMPORT A SINGLE VIDEO WITH REAL-TIME PROGRESS
   ================================================================== */
   app.post("/api/transcribe-youtube", (req, res) => {
     const { url, importId } = req.body;
     if (!url) return res.status(400).json({ error: "Missing YouTube URL" });
     if (!importId) return res.status(400).json({ error: "Missing import ID" });
   
     console.log("🚀 Starting transcription for URL:", url, "Import ID:", importId);
   
     // Start the import process immediately and return
     res.json({ importId, status: "started" });
   
     // Run the bash script with spawn for real-time output
     const scriptProcess = spawn('bash', ['youtube_transcribe.sh', url], {
       stdio: ['ignore', 'pipe', 'pipe']
     });
   
     let scriptOutput = '';
     let currentStage = 'Starting';
     let currentProgress = 0;
   
     // Send initial progress
     sendProgress(importId, currentStage, currentProgress);
   
     scriptProcess.stdout.on('data', (data) => {
       const output = data.toString();
       scriptOutput += output;
       
       const lines = output.split('\n');
       for (const line of lines) {
         if (line.startsWith('STAGE:')) {
           currentStage = line.replace('STAGE:', '').trim();
           sendProgress(importId, currentStage, currentProgress);
           console.log(`📍 Stage: ${currentStage}`);
         } else if (line.startsWith('PROGRESS:')) {
           currentProgress = parseInt(line.replace('PROGRESS:', '').trim());
           sendProgress(importId, currentStage, currentProgress);
           console.log(`📊 Progress: ${currentProgress}%`);
         } else if (line.startsWith('DEBUG:')) {
           console.log(`🐛 Debug: ${line.replace('DEBUG:', '').trim()}`);
         }
       }
     });
   
     scriptProcess.stderr.on('data', (data) => {
       const stderrOutput = data.toString();
       console.error('Script stderr:', stderrOutput);
       
       // Check for specific error patterns
       if (stderrOutput.includes('ERROR:') || stderrOutput.includes('error:')) {
         sendProgress(importId, 'Error: Script failed', 0);
       }
     });
   
     scriptProcess.on('close', async (code) => {
       if (code !== 0) {
         console.error("❌ Shell script failed with code:", code);
         sendProgress(importId, 'Error', 0);
         return;
       }
   
       console.log("✅ Script completed successfully");
       console.log("📋 Script output:", scriptOutput);
   
       const lines = scriptOutput.split("\n");
       
       // Parse the script output
       const fileLine = lines.find((l) => l.startsWith("FILE:"));
       const titleLine = lines.find((l) => l.startsWith("TITLE:"));
       const channelLine = lines.find((l) => l.startsWith("CHANNEL:"));
       const publishLine = lines.find((l) => l.startsWith("PUBLISH:"));
       
       if (!fileLine) {
         console.error("❌ No FILE: line found in output");
         sendProgress(importId, 'Error', 0);
         return;
       }
   
       // Extract values
       const filename = fileLine.replace("FILE:", "").trim();
       const title = titleLine ? titleLine.replace("TITLE:", "").trim() : "Untitled";
       const channel = channelLine ? channelLine.replace("CHANNEL:", "").trim() : "Unknown";
       const publishDateStr = publishLine ? publishLine.replace("PUBLISH:", "").trim() : null;
       
       // Extract YouTube ID from the filename (yt_ABC123.txt -> ABC123)
       const youtubeId = filename.replace("yt_", "").replace(".txt", "");
   
       try {
         // READ THE CORRECT FILE
         const transcriptPath = path.join(process.cwd(), filename);
         console.log("📂 Reading transcript from:", transcriptPath);
         
         const transcript = await fs.readFile(transcriptPath, "utf-8");
         console.log("✅ File read successfully, length:", transcript.length);
         
         // Parse publish date
         let publishDate = null;
         if (publishDateStr) {
           try {
             publishDate = new Date(publishDateStr);
           } catch (e) {
             console.warn("⚠️ Failed to parse publish date:", publishDateStr);
           }
         }
         
         // Save to database using Prisma
         console.log("💾 Saving to database...");
         const savedTranscript = await prisma.transcript.create({
           data: {
             youtubeId,
             title,
             channel,
             text: transcript,
             publishDate,
             source: 'YOUTUBE',
             sourceUrl: url
           }
         });
         
         console.log("✅ Saved to database with ID:", savedTranscript.id);
         
         // Clean up the transcript file after saving to database
         try {
           await fs.unlink(transcriptPath);
           console.log("🗑️ Cleaned up transcript file:", filename);
         } catch (cleanupErr) {
           console.warn("⚠️ Could not clean up file:", filename, cleanupErr.message);
         }
         
         console.log("🎉 Import completed successfully!");
         
         // Send completion status
         sendProgress(importId, 'Completed', 100);
         
       } catch (dbError) {
         console.error("❌ Database error:", dbError);
         
         if (dbError.code === 'P2002') {
           sendProgress(importId, 'Error: Video already imported', 0);
         } else if (dbError.code === 'ENOENT') {
           sendProgress(importId, 'Error: File not found', 0);
         } else {
           sendProgress(importId, 'Error: Save failed', 0);
         }
       } finally {
         // Clean up the WebSocket connection
         setTimeout(() => {
           activeImports.delete(importId);
         }, 5000);
       }
     });
   });
   
   /* ==================================================================
      /api/channel-info  – CHECK CHANNEL (count + first/last upload date)
      ================================================================== */
   app.post("/api/channel-info", (req, res) => {
     const { url } = req.body;
     if (!url) return res.status(400).json({ error: "Missing channel URL" });
   
     exec(
       `yt-dlp -s --flat-playlist --print "%(upload_date)s" "${url}"`,
       (err, stdout) => {
         if (err) {
           console.error(err);
           return res.status(500).json({ error: "yt-dlp failed" });
         }
   
         const lines  = stdout.trim().split("\n").filter(Boolean);
         const dates  = lines.filter((d) => /^\d{8}$/.test(d));
         const total  = lines.length;
         const first  = dates.length ? dates.at(-1) : null; // oldest
         const latest = dates.length ? dates[0]     : null; // newest
   
         res.json({ total, firstDate: first, lastDate: latest });
       }
     );
   });
   
   /* ==================================================================
      /api/channel-last-videos  – LIST NEWEST N VIDEO URLs (BULK IMPORT)
      ================================================================== */
   app.post("/api/channel-last-videos", (req, res) => {
     const { url, count = 10 } = req.body;
     if (!url)  return res.status(400).json({ error: "Missing channel URL" });
   
     exec(
       `yt-dlp -s --flat-playlist --print "%(upload_date)s|%(id)s" "${url}"`,
       (err, stdout) => {
         if (err) {
           console.error(err);
           return res.status(500).json({ error: "yt-dlp failed" });
         }
   
         const videos = stdout
           .trim()
           .split("\n")
           .filter(Boolean)
           .map((l) => l.split("|"))                  // [YYYYMMDD, id]
           .sort((a, b) => b[0].localeCompare(a[0])) // newest first
           .slice(0, Number(count))
           .map(([, id]) => `https://youtu.be/${id}`);
   
         res.json({ videos });
       }
     );
   });
   
   /* ==================================================================
      /api/podcast-feed - FETCH AND PARSE PODCAST RSS FEED
      ================================================================== */
   app.post("/api/podcast-feed", async (req, res) => {
     const { url } = req.body;
     if (!url) return res.status(400).json({ error: "Missing podcast feed URL" });
   
     try {
       console.log("Fetching podcast feed from:", url);
       
       // Fetch the RSS feed
       const response = await fetch(url);
       if (!response.ok) {
         console.error(`Failed to fetch feed: HTTP ${response.status}`);
         return res.status(500).json({ error: `Failed to fetch feed: HTTP ${response.status}` });
       }
   
       const xmlData = await response.text();
       console.log("Fetched XML data, length:", xmlData.length);
       
       // Check if it's actually XML/RSS
       if (!xmlData.includes('<rss') && !xmlData.includes('<?xml')) {
         console.error("Response doesn't appear to be RSS/XML");
         return res.status(400).json({ error: "URL does not appear to be an RSS feed" });
       }
   
       const parser = new xml2js.Parser({ 
         explicitArray: false,
         mergeAttrs: true,
         normalize: true,
         normalizeTags: true,
         trim: true
       });
       
       const result = await parser.parseStringPromise(xmlData);
       console.log("Parsed XML successfully");
   
       // Extract podcast info
       const channel = result.rss.channel;
       if (!channel) {
         return res.status(400).json({ error: "Invalid RSS feed format" });
       }
   
       const podcastInfo = {
         title: channel.title || "Unknown Podcast",
         description: channel.description || "",
         imageUrl: channel.image?.url || channel.image?.href || "",
         author: channel.author || channel.managingEditor || "",
         episodes: []
       };
   
       // Extract episodes
       let items = channel.item || [];
       if (!Array.isArray(items)) {
         items = [items];
       }
   
       podcastInfo.episodes = items.map((item, index) => {
         // Find audio enclosure
         let audioUrl = "";
         if (item.enclosure) {
           if (Array.isArray(item.enclosure)) {
             // Find audio enclosure
             const audioEnclosure = item.enclosure.find(enc => 
               enc.type && enc.type.startsWith('audio/')
             );
             audioUrl = audioEnclosure?.url || item.enclosure[0]?.url || "";
           } else {
             audioUrl = item.enclosure.url || "";
           }
         }
   
         return {
           id: item.guid || `episode-${index}`,
           title: item.title || `Episode ${index + 1}`,
           description: item.description || "",
           publishDate: item.pubdate || "",
           duration: item.duration || "",
           audioUrl: audioUrl
         };
       }).filter(episode => episode.audioUrl); // Only include episodes with audio
   
       console.log(`Found ${podcastInfo.episodes.length} episodes with audio`);
       res.json(podcastInfo);
     } catch (error) {
       console.error("Error parsing podcast feed:", error);
       res.status(500).json({ error: "Failed to parse podcast feed: " + error.message });
     }
   });
   
   /* ==================================================================
      /api/transcribe-podcast - DOWNLOAD AND TRANSCRIBE PODCAST EPISODE
      ================================================================== */
   app.post("/api/transcribe-podcast", async (req, res) => {
     const { url, title, publishDate, podcastName } = req.body;
     if (!url) return res.status(400).json({ error: "Missing podcast audio URL" });
   
     try {
       console.log("Starting podcast transcription for:", title);
       
       // Check if this podcast episode already exists
       const existingTranscript = await prisma.transcript.findFirst({
         where: {
           sourceUrl: url,
           source: 'PODCAST'
         }
       });
       
       if (existingTranscript) {
         return res.status(400).json({ error: "This podcast episode has already been imported" });
       }
       
       // Create a temporary filename based on current timestamp
       const timestamp = Date.now();
       const audioFile = `podcast_${timestamp}.mp3`;
       const txtFile = `podcast_${timestamp}.txt`;
       
       // Download the audio file
       console.log("Downloading audio from:", url);
       await execPromise(`curl -L "${url}" -o "${audioFile}"`);
       
       // Transcribe using whisper.cpp
       console.log("Starting transcription...");
       await execPromise(`cd whisper.cpp && ./build/bin/whisper-cli -m models/ggml-base.en.bin -f "../${audioFile}" -otxt -of "../${txtFile.replace('.txt', '')}"`);
       
       // Read the transcription
       const transcript = await fs.readFile(txtFile, "utf-8");
       console.log("Transcription completed, length:", transcript.length);
       
       // Clean up the files
       try {
         await fs.unlink(audioFile);
         await fs.unlink(txtFile);
       } catch (cleanupError) {
         console.warn("Failed to clean up temporary files:", cleanupError);
       }
       
       // Parse publish date
       let parsedPublishDate = null;
       if (publishDate) {
         try {
           parsedPublishDate = new Date(publishDate);
         } catch (e) {
           console.warn("Failed to parse publish date:", publishDate);
         }
       }
       
       // Save to database using Prisma
       const savedTranscript = await prisma.transcript.create({
         data: {
           title: title || "Unknown Episode",
           channel: podcastName || "Unknown Podcast",
           text: transcript,
           publishDate: parsedPublishDate,
           source: 'PODCAST',
           sourceUrl: url
         }
       });
       
       // Return the transcription and metadata
       res.json({
         title: savedTranscript.title,
         transcript,
         publishDate: savedTranscript.publishDate,
         channel: savedTranscript.channel,
         id: savedTranscript.id
       });
     } catch (error) {
       console.error("Podcast transcription error:", error);
       res.status(500).json({ error: "Failed to transcribe podcast: " + error.message });
     }
   });
   
   /* ==================================================================
      /api/insights - GET ALL INSIGHTS
      ================================================================== */
   app.get("/api/insights", async (req, res) => {
     try {
       const { tags, channel } = req.query;
       
       const whereClause = {};
       if (tags) {
         whereClause.tags = {
           hasSome: tags.split(',')
         };
       }
       if (channel) {
         whereClause.channel = channel;
       }
       
       const insights = await prisma.insight.findMany({
         where: whereClause,
         orderBy: { createdAt: 'desc' }
       });
       
       res.json(insights);
     } catch (error) {
       console.error("Error fetching insights:", error);
       res.status(500).json({ error: "Failed to fetch insights" });
     }
   });
   
   /* ==================================================================
      /api/insights/:id - GET SINGLE INSIGHT
      ================================================================== */
   app.get("/api/insights/:id", async (req, res) => {
     try {
       const insight = await prisma.insight.findUnique({
         where: { id: req.params.id }
       });
       
       if (!insight) {
         return res.status(404).json({ error: "Insight not found" });
       }
       
       res.json(insight);
     } catch (error) {
       console.error("Error fetching insight:", error);
       res.status(500).json({ error: "Failed to fetch insight" });
     }
   });
   
   /* ==================================================================
      /api/insights - CREATE NEW INSIGHT
      ================================================================== */
   app.post("/api/insights", async (req, res) => {
     try {
       const { title, content, tags, channel, publishDate } = req.body;
       
       if (!title || !content) {
         return res.status(400).json({ error: "Title and content are required" });
       }
       
       let parsedPublishDate = null;
       if (publishDate) {
         try {
           parsedPublishDate = new Date(publishDate);
         } catch (e) {
           console.warn("Failed to parse publish date:", publishDate);
         }
       }
       
       const insight = await prisma.insight.create({
         data: {
           title,
           content,
           tags: tags || [],
           channel: channel || "",
           publishDate: parsedPublishDate
         }
       });
       
       res.json(insight);
     } catch (error) {
       console.error("Error creating insight:", error);
       res.status(500).json({ error: "Failed to create insight" });
     }
   });
   
   /* ==================================================================
      /api/insights/:id - UPDATE INSIGHT
      ================================================================== */
   app.put("/api/insights/:id", async (req, res) => {
     try {
       const { title, content, tags, channel, publishDate } = req.body;
       
       let parsedPublishDate = null;
       if (publishDate) {
         try {
           parsedPublishDate = new Date(publishDate);
         } catch (e) {
           console.warn("Failed to parse publish date:", publishDate);
         }
       }
       
       const insight = await prisma.insight.update({
         where: { id: req.params.id },
         data: {
           title,
           content,
           tags: tags || [],
           channel: channel || "",
           publishDate: parsedPublishDate
         }
       });
       
       res.json(insight);
     } catch (error) {
       if (error.code === 'P2025') {
         return res.status(404).json({ error: "Insight not found" });
       }
       console.error("Error updating insight:", error);
       res.status(500).json({ error: "Failed to update insight" });
     }
   });
   
   /* ==================================================================
      /api/insights/:id - DELETE INSIGHT
      ================================================================== */
   app.delete("/api/insights/:id", async (req, res) => {
     try {
       await prisma.insight.delete({
         where: { id: req.params.id }
       });
       res.json({ success: true });
     } catch (error) {
       if (error.code === 'P2025') {
         return res.status(404).json({ error: "Insight not found" });
       }
       console.error("Error deleting insight:", error);
       res.status(500).json({ error: "Failed to delete insight" });
     }
   });
   
   /* ==================================================================
      /api/import-progress - For bulk import progress tracking
      ================================================================== */
   app.get("/api/import-progress", (req, res) => {
     // This is a placeholder - you can implement proper progress tracking if needed
     res.json({
       PENDING: 0,
       PROCESSING: 0,
       DONE: 0,
       ERROR: 0
     });
   });
   
   /* ==================================================================
      /api/bulk-import - For bulk podcast import
      ================================================================== */
   app.post("/api/bulk-import", async (req, res) => {
     const { videos } = req.body;
     if (!videos || !Array.isArray(videos)) {
       return res.status(400).json({ error: "Missing videos array" });
     }
     
     // For now, just return empty skipped array
     // You can implement actual bulk processing here
     res.json({ skipped: [] });
   });
   
   /* ==================================================================
      /api/import-jobs – GET CURRENT IMPORT JOBS
      ================================================================== */
   app.get("/api/import-jobs", async (req, res) => {
     try {
       const { status } = req.query;
       
       // Validate status query if provided
       const allowedStatus = ['active', 'pending', 'processing', 'done', 'error'];
       if (status && !allowedStatus.includes(String(status).toLowerCase())) {
         return res.status(400).json({ error: "Invalid status filter" });
       }
       
       // Build optional filtering based on status
       const whereClause = {};
       
       if (status && String(status).toLowerCase() === 'active') {
         // Treat active as jobs that are pending or currently processing
         whereClause.state = { in: ['PENDING', 'PROCESSING'] };
       } else if (status) {
         // Map to single state filter (uppercase enum)
         whereClause.state = String(status).toUpperCase();
       }
       
       const jobs = await prisma.importJob.findMany({
         where: whereClause,
         select: {
           id: true,
           state: true,
           progress: true
         },
         orderBy: { createdAt: 'desc' }
       });
       res.json(jobs);
     } catch (error) {
       console.error("Error fetching import jobs:", error);
       res.status(500).json({ error: "Failed to fetch import jobs" });
     }
   });
   
   /* ==================================================================
      Optional: serve the Vite build from /dist if present
      ================================================================== */
   const webDir = path.join(__dirname, "dist");
   if (existsSync(webDir)) {
     app.use(express.static(webDir));
     app.get("*", (_req, res) =>
       res.sendFile(path.join(webDir, "index.html"))
     );
   }
   
   // Clean up Prisma connection on exit
   process.on('beforeExit', async () => {
     await prisma.$disconnect();
   });
   
   /* ----- start ------------------------------------------------------ */
   server.listen(PORT, () => {
     console.log(`>>> API listening on http://localhost:${PORT}`);
     console.log(`>>> WebSocket server ready for real-time progress updates`);
     
     // Log registered routes
     if (app._router && app._router.stack) {
       console.log("Registered routes:");
       app._router.stack
         .filter((l) => l.route)
         .forEach((l) =>
           console.log(
             "  ",
             Object.keys(l.route.methods)[0].toUpperCase(),
             l.route.path
           )
         );
     }
   });

export { app };