'use client'

/* ─────────────────────────────────────────────────────
   Layout with persistent chat context
   ──────────────────────────────────────────────────── */

import { NavigationProvider } from '../contexts/NavigationContext'
import { ChatProvider } from '../contexts/ChatContext'
import { ImportProvider } from '../contexts/ImportContext'
import Sidebar from './Sidebar'
import MainContent from './MainContent'

export default function LayoutV2() {
  return (
    <NavigationProvider>
      <ChatProvider>
        <ImportProvider>
          <div className="flex">
            <Sidebar />
            <MainContent />
          </div>
        </ImportProvider>
      </ChatProvider>
    </NavigationProvider>
  )
}