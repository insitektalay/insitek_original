import { useEffect, useState } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit  from "@tiptap/starter-kit";
import Bold        from "@tiptap/extension-bold";
import Italic      from "@tiptap/extension-italic";
import Heading     from "@tiptap/extension-heading";
import BulletList  from "@tiptap/extension-bullet-list";
import ListItem    from "@tiptap/extension-list-item";
import Link        from "@tiptap/extension-link";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

export default function InsightEditor({ onClose, editingInsight, onSaved, autoCapturedContent }) {
  const [title,setTitle]       = useState(editingInsight?.title || "");
  const [channel,setChannel]   = useState(editingInsight?.channel || "");
  const [tags,setTags]         = useState(editingInsight?.tags || []);
  const [publish,setPublish]   = useState(editingInsight?.publishDate || "");
  const [input,setInput]       = useState("");
  const [status,setStatus]     = useState("");

  const editor = useEditor({
    extensions:[
      StarterKit,Bold,Italic,
      Heading.configure({ levels:[1,2,3] }),
      BulletList,ListItem,Link,
    ],
    content:editingInsight?.content || "",
  });

  // Handle editing existing insight
  useEffect(()=>{
    if(!editingInsight||!editor) return;
    editor.commands.setContent(editingInsight.content);
    setTitle(editingInsight.title);
    setChannel(editingInsight.channel);
    setTags(editingInsight.tags);
    setPublish(editingInsight.publishDate);
  },[editingInsight,editor]);

  // Handle auto-captured content from chat
  useEffect(() => {
    if (autoCapturedContent && editor) {
      // Set suggested title if title is empty
      if (!title && autoCapturedContent.suggestedTitle) {
        setTitle(autoCapturedContent.suggestedTitle);
      }
      
      const newContent = autoCapturedContent.content;
      const currentContent = editor.getHTML();
      const currentText = editor.getText();
      
      // Enhanced duplicate detection
      const contentPreview = newContent.substring(0, 150).toLowerCase();
      const existingContentLower = currentText.toLowerCase();
      
      if (existingContentLower.includes(contentPreview)) {
        console.log("Duplicate content detected, skipping...");
        setStatus("Duplicate content detected - not added");
        setTimeout(() => setStatus(""), 2000);
        return;
      }
      
      // If editor is empty, set the content directly
      if (!currentContent || currentContent === '<p></p>' || currentText.trim().length === 0) {
        editor.commands.setContent(`<p>${newContent}</p>`);
      } else {
        // Append to existing content WITHOUT separator headers
        editor.commands.setContent(`${currentContent}<p>${newContent}</p>`);
      }
      
      // Auto-tag based on source
      let autoTag = 'auto-captured';
      if (autoCapturedContent.source === 'chat_smart_selective') {
        autoTag = 'smart-extract';
      } else if (autoCapturedContent.source?.includes('condensed')) {
        autoTag = 'condensed';
      }
      
      if (!tags.includes(autoTag)) {
        setTags(prev => [...prev, autoTag]);
      }
      
      const sourceLabel = autoCapturedContent.source?.includes('condensed') ?
        'Condensed content captured from chat!' :
        autoCapturedContent.source === 'chat_smart_selective' ? 
        'Smart insight extracted from chat!' : 'Content auto-captured from chat!';
      
      setStatus(sourceLabel);
      setTimeout(() => setStatus(""), 3000);
    }
  }, [autoCapturedContent, editor, title, tags]);

  const commitInput = ()=>{
    const add = input.split(",").map(s=>s.trim()).filter(Boolean)
                     .filter(t=>!tags.includes(t));
    if(add.length) setTags([...tags,...add]);
    setInput("");
  };

  const generateHeaderForSelection = async () => {
    const selectedText = window.getSelection().toString().trim();
    
    if (!selectedText) {
      alert("Please select some text first, then click this button to generate a header");
      return;
    }

    if (selectedText.length < 20) {
      alert("Please select more text to generate a meaningful header");
      return;
    }

    try {
      const prompt = `Generate a short, descriptive header (2-6 words) for this text section:

"${selectedText.substring(0, 300)}..."

The header should be concise and capture the main topic or theme. Return only the header text, nothing else.

Header:`;

      const response = await fetch("http://localhost:8080/completion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          temperature: 0.3,
          n_predict: 50,
          stop: ["Header:", "\n\n", "Text:"]
        })
      });

      if (!response.ok) throw new Error("Header generation failed");

      const data = await response.json();
      const headerText = (data.content || data.completion || "").trim();

      if (headerText && headerText.length > 0) {
        // Use TipTap's proper commands to insert the header
        // First, we need to find and select the text in the editor
        const currentText = editor.getText();
        const textPosition = currentText.indexOf(selectedText);
        
        if (textPosition !== -1) {
          // Position cursor at the start of the selected text
          editor.commands.setTextSelection({
            from: textPosition + 1,
            to: textPosition + 1
          });
          
          // Insert the header before the selected text
          editor.commands.insertContent(`<h3><strong>${headerText}</strong></h3><p></p>`);
          
          setStatus(`Generated header: "${headerText}"`);
          setTimeout(() => setStatus(""), 3000);
        } else {
          // Fallback: just insert the header at current cursor position
          editor.commands.insertContent(`<h3><strong>${headerText}</strong></h3><p></p>`);
          setStatus(`Generated header: "${headerText}" (inserted at cursor)`);
          setTimeout(() => setStatus(""), 3000);
        }
      } else {
        alert("Failed to generate header");
      }
    } catch (error) {
      console.error("Header generation error:", error);
      alert("Failed to generate header");
    }
  };

  const convertToBulletPoints = () => {
    const selectedText = window.getSelection().toString().trim();
    
    if (!selectedText) {
      alert("Please select some text first, then click this button to convert to bullet points");
      return;
    }

    if (selectedText.length < 20) {
      alert("Please select more text to convert to bullet points");
      return;
    }

    // Split text into sentences and create bullet points
    const sentences = selectedText
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 10);

    if (sentences.length === 0) {
      alert("Could not split selected text into bullet points");
      return;
    }

    // Create bullet point list
    const bulletPoints = sentences.map(sentence => 
      sentence.startsWith('•') ? sentence : `• ${sentence}`
    ).join('\n');

    // Replace selected text with bullet points in editor
    const currentContent = editor.getHTML();
    const newContent = currentContent.replace(selectedText, bulletPoints.replace(/\n/g, '<br>'));
    editor.commands.setContent(newContent);
    
    setStatus("Converted selected text to bullet points!");
    setTimeout(() => setStatus(""), 2000);
  };

  const generateTitleSuggestions = async () => {
    if (!editor) return;
    
    const content = editor.getText();
    if (!content || content.length < 50) {
      alert("Please add some content first before generating title suggestions.");
      return;
    }

    try {
      setStatus("Generating title suggestions...");
      
      const prompt = `Based on this insight content, suggest 5 concise, descriptive titles (each under 60 characters):

CONTENT:
${content}

Generate titles that capture the main theme or key insight. Return only the titles, one per line, numbered 1-5.

Titles:
1.`;

      const response = await fetch("http://localhost:8080/completion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          temperature: 0.7,
          n_predict: 200,
          stop: ["CONTENT:", "USER:", "AI:"]
        })
      });

      if (!response.ok) throw new Error("Failed to generate titles");

      const data = await response.json();
      const suggestions = data.content || data.completion || "";
      
      // Parse the suggestions
      const titles = suggestions
        .split('\n')
        .map(line => line.replace(/^\d+[\.)]\s*/, '').trim())
        .filter(line => line.length > 0 && line.length < 80)
        .slice(0, 5);

      if (titles.length > 0) {
        const selectedTitle = window.prompt(
          `Choose a title or edit one:\n\n${titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nEnter the number (1-${titles.length}) or type a custom title:`,
          "1"
        );

        if (selectedTitle) {
          const titleIndex = parseInt(selectedTitle) - 1;
          if (titleIndex >= 0 && titleIndex < titles.length) {
            setTitle(titles[titleIndex]);
          } else if (selectedTitle.trim()) {
            setTitle(selectedTitle.trim());
          }
        }
      }
      
      setStatus("");
    } catch (error) {
      console.error("Title generation error:", error);
      setStatus("Failed to generate titles");
      setTimeout(() => setStatus(""), 2000);
    }
  };

  const save = async ()=>{
    if(!title.trim()) return alert("Title required");
    commitInput();

    const payload = {
      title: title.trim(),
      content: editor?.getHTML() || "",
      tags,
      channel,
      publishDate: publish,
    };

    const url    = `${API_URL}/api/insights` + (editingInsight ? `/${editingInsight.id}`:"");
    const method = editingInsight ? "PUT":"POST";

    try {
      const response = await fetch(url, { 
        method, 
        headers: { "Content-Type": "application/json" }, 
        body: JSON.stringify(payload) 
      });
      
      if (!response.ok) throw new Error("Failed to save insight");
      
      setStatus("Saved!");
      setTimeout(()=>setStatus(""),2000);
      onSaved?.(); 
      onClose();
    } catch (error) {
      console.error("Save error:", error);
      setStatus("Save failed!");
      setTimeout(()=>setStatus(""),2000);
    }
  };

  return(
    <div className="p-4 h-full flex flex-col space-y-3 text-xs overflow-auto relative">
      <div className="space-y-3 flex-1 overflow-auto">
        {/* Title input with AI suggestions */}
        <div className="space-y-2">
          <div className="flex gap-2">
            <input 
              value={title} 
              onChange={e=>setTitle(e.target.value)}
              placeholder="insight title…" 
              className="flex-1 border rounded px-3 py-2 text-xs"
            />
            <button
              onClick={generateTitleSuggestions}
              className="bg-purple-500 hover:bg-purple-600 text-white text-[10px] px-3 py-2 rounded"
              title="Generate AI title suggestions"
            >
              🤖 Suggest Titles
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          <span className="bg-green-100 text-green-600 text-[10px] px-2 py-[2px] rounded-full">
            {channel}
          </span>
          {publish && (
            <span className="bg-gray-100 text-gray-600 text-[10px] px-2 py-[2px] rounded-full">
              {new Date(publish).toLocaleDateString()}
            </span>
          )}
          {autoCapturedContent && (
            <span className="bg-yellow-100 text-yellow-600 text-[10px] px-2 py-[2px] rounded-full">
              Auto-Captured
            </span>
          )}
        </div>

        {/* tags */}
        <div className="flex flex-wrap gap-1">
          {tags.map(t=>(
            <span key={t}
                  className="bg-blue-100 text-blue-600 text-[10px] px-2 py-[2px] rounded-full flex items-center gap-1">
              {t}
              <button onClick={()=>setTags(tags.filter(x=>x!==t))} className="text-[10px]">×</button>
            </span>
          ))}
          <input value={input} onChange={e=>setInput(e.target.value)}
                 onKeyDown={e=>{ if(e.key==="Enter"||e.key===","){ e.preventDefault(); commitInput(); } }}
                 onBlur={commitInput}
                 placeholder="add tag…" className="border rounded px-1 text-[10px] w-24"/>
        </div>

        <div className="flex-1 overflow-y-auto border rounded">
          <EditorContent 
            editor={editor} 
            className="px-3 py-2 leading-tight" 
            style={{
              minHeight:"300px",
              fontSize:"11px !important"
            }}
          />
          <style jsx>{`
            .ProseMirror {
              font-size: 11px !important;
              line-height: 1.3 !important;
            }
            .ProseMirror p {
              font-size: 11px !important;
              margin: 0.25em 0 !important;
            }
            .ProseMirror * {
              font-size: 11px !important;
            }
          `}</style>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            <button onClick={convertToBulletPoints}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-3 py-1.5 rounded text-[10px] border-2 border-gray-400">
              Make Bullets
            </button>
            <button onClick={generateHeaderForSelection}
                    className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1.5 rounded text-[10px] border-2 border-gray-500">
              Generate Header
            </button>
          </div>
          <button onClick={save}
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-xs font-bold">
            Save Insight
          </button>
        </div>
        {status && <div className={`text-xs mt-2 ${status.includes('failed') ? 'text-red-600' : 'text-green-600'}`}>{status}</div>}
      </div>
    </div>
  );
}