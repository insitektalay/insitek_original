/* ────────────────────────────────────────────────
   src/v2/components/ui/ChatPanel.jsx
   ─ persistent chat panel (matches existing hooks)
   ──────────────────────────────────────────────── */
   import { useCallback, useEffect, useRef, useState } from 'react'
   import { useChat } from '../../contexts/ChatContext'
   import { useInsightExtraction } from '../../hooks/useInsightExtraction'
   import { useTransferFunctions } from '../../hooks/useTransferFunctions'
   import InsightSuggestions from './InsightSuggestions'
   import ManualCaptureControls from './ManualCaptureControls'
   
   export default function ChatPanel ({
     onClose,
     transcript,
     onSuggestPrompts,
     onCaptureInsight,
   }) {
     /* ───────── context ───────── */
     const {
       getChatSession,
       updateChatSession,
       addMessage,
       setLoading,
     } = useChat()
   
     /* ───────── hydrate ───────── */
     const initial = getChatSession(transcript?.id)
     const [messages, setMessages] = useState(initial.messages)
     const [input, setInput]       = useState(initial.input)
     const [thinking, setThinking] = useState(initial.isLoading)
   
     /* ───────── hooks ───────── */
     const {
       insightSuggestions = [],         // ← default so .length is safe
       runInsightDetection,
       handleCaptureInsight,
       dismissInsightSuggestion,
       clearInsightSuggestions,
     } = useInsightExtraction()
   
     const {
       transferLastResponse,
       transferSelectedText,
       transferCondensedResponse,
     } = useTransferFunctions()
   
     const listRef = useRef(null)
   
     /* ───────── re-hydrate on transcript change ───────── */
     useEffect(() => {
       if (!transcript?.id) return
       const s = getChatSession(transcript.id)
       setMessages(s.messages)
       setInput(s.input)
       setThinking(s.isLoading)
   
       clearInsightSuggestions()
       ;(s.insightSuggestions || []).forEach((i) =>
         runInsightDetection(i.text, i.messageIndex),
       )
     }, [transcript?.id])
   
     /* ───────── persist every change ───────── */
     useEffect(() => {
       if (!transcript?.id) return
       updateChatSession(transcript.id, {
         messages,
         input,
         isLoading: thinking,
         insightSuggestions,
       })
     }, [messages, input, thinking, insightSuggestions, transcript?.id])
   
     /* ───────── auto-scroll ───────── */
     useEffect(() => {
       if (listRef.current) {
         listRef.current.scrollTop = listRef.current.scrollHeight
       }
     }, [messages, thinking])
   
     /* ───────── send / stream ───────── */
     const send = useCallback(async (forcedText = null) => {
       if (!transcript?.id) return
       const text = (forcedText ?? input).trim()
       if (!text) return
   
       const userMsg = { role: 'user', content: text }
       addMessage(transcript.id, userMsg)
       setMessages((m) => [...m, userMsg])
       runInsightDetection(text, messages.length)
   
       setInput('')
       setThinking(true)
       setLoading(transcript.id, true)
   
       /* ---- stream assistant reply ---- */
       const res = await fetch('http://localhost:8080/completion', {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify({
           prompt: `You are an expert assistant. Use this transcript as reference:\n${transcript.text}\n\nUser: ${text}\nAI:`,
           temperature: 0.7,
           stop: ['User:', 'AI:'],
           n_predict: 512,
           stream: true,
         }),
       })
       if (!res.ok || !res.body) {
         setThinking(false)
         setLoading(transcript.id, false)
         return alert('AI request failed')
       }
   
       const reader  = res.body.getReader()
       const decoder = new TextDecoder('utf-8')
       let   buffer  = ''
       let   full    = ''
   
       /* create assistant shell message */
       setMessages((m) => [...m, { role: 'assistant', content: '' }])
   
       while (true) {
         const { value, done } = await reader.read()
         if (done) break
         buffer += decoder.decode(value, { stream: true })
         const lines = buffer.split('\n')
         buffer = lines.pop()
   
         for (const line of lines) {
           if (!line.startsWith('data: ')) continue
           const payload = line.slice(6).trim()
           if (payload === '[DONE]') break
           try {
             const { content } = JSON.parse(payload)
             if (content) {
               full += content
               setMessages((m) => {
                 const nxt = [...m]
                 nxt[nxt.length - 1] = { role: 'assistant', content: full }
                 return nxt
               })
             }
           } catch {/* ignore malformed chunk */}
         }
       }
   
       /* prompt-deck suggestions & insight detection */
       if (onSuggestPrompts) {
         const chatText = [
           ...messages,
           userMsg,
           { role: 'assistant', content: full },
         ].map((m) => `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`).join('\n')
         onSuggestPrompts(chatText)
       }
       runInsightDetection(full, messages.length + 1)
   
       setThinking(false)
       setLoading(transcript.id, false)
     }, [
       transcript?.id,
       input,
       messages.length,
       addMessage,
       setLoading,
       runInsightDetection,
       onSuggestPrompts,
     ])
   
     /* ───────── UI ───────── */
     return (
       <div className="p-4 h-full flex flex-col space-y-4 text-xs relative">
         {/* Close button removed for minimal layout */}
   
         <div ref={listRef} className="flex-1 overflow-auto space-y-4">
           {!transcript ? (
             <div className="bg-gray-100 p-2 italic rounded">
               No transcript selected.
             </div>
           ) : (
             <>
               <div className="bg-gray-100 p-2 rounded text-[11px]">
                 <strong>{transcript.title}</strong>
                 <span className="ml-2 bg-green-100 text-green-600 px-2 py-[2px] rounded-full">
                   {transcript.channel}
                 </span>
               </div>
   
               {messages.map((m, i) => (
                 <div key={i} className="relative">
                   <div className={m.role === 'user' ? 'text-blue-600' : 'text-gray-700'}>
                     <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
                     {m.content}
                   </div>
   
                   {m.role === 'assistant' && (
                     <InsightSuggestions
                       messageIndex={i}
                       insightSuggestions={insightSuggestions}
                       onCaptureInsight={(s) => handleCaptureInsight(s, onCaptureInsight)}
                       onDismissSuggestion={dismissInsightSuggestion}
                     />
                   )}
                 </div>
               ))}
   
               {thinking && <div className="italic text-gray-400">AI is thinking…</div>}
   
               <ManualCaptureControls
                 messages={messages}
                 onTransferLastResponse={() =>
                   transferLastResponse(messages, onCaptureInsight)}
                 onTransferSelectedText={() =>
                   transferSelectedText(onCaptureInsight)}
                 onTransferCondensedResponse={(lvl) =>
                   transferCondensedResponse(messages, lvl, onCaptureInsight)}
               />
             </>
           )}
         </div>
   
         <div className="pt-2 border-t flex">
           <input
             className="flex-1 border rounded px-2 py-1 text-xs border-gray-300"
             placeholder="Type your question…"
             value={input}
             onChange={(e) => setInput(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && send()}
             disabled={!transcript}
           />
           <button
             onClick={() => send()}
             disabled={!transcript || thinking}
             className="ml-2 bg-blue-500 hover:bg-blue-600 text-white rounded text-xs px-4 disabled:opacity-50"
           >
             Send
           </button>
         </div>
       </div>
     )
   }
   