// src/v2/components/ui/InsightSuggestions.jsx

export default function InsightSuggestions({ 
    messageIndex, 
    insightSuggestions, 
    onCaptureInsight, 
    onDismissSuggestion 
  }) {
    const relevantSuggestions = insightSuggestions.filter(
      suggestion => suggestion.messageIndex === messageIndex
    );
  
    if (relevantSuggestions.length === 0) return null;
  
    return (
      <>
        {relevantSuggestions.map(suggestion => (
          <div key={suggestion.timestamp} className={`mt-2 p-3 rounded-r border-l-4 ${
            suggestion.type === 'selective' 
              ? 'bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-400' 
              : 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-400'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-[11px] font-bold ${
                    suggestion.type === 'selective' 
                      ? 'text-blue-700' 
                      : 'text-yellow-700'
                  }`}>
                    {suggestion.type === 'selective' ? '🎯 SMART EXTRACT' : '📄 FULL RESPONSE'}
                  </span>
                  <span className={`text-[8px] px-1 py-[1px] rounded uppercase font-bold ${
                    suggestion.type === 'selective' 
                      ? 'bg-blue-200 text-blue-800' 
                      : 'bg-yellow-200 text-yellow-800'
                  }`}>
                    {suggestion.type === 'selective' ? 'SELECTIVE' : 'COMPLETE'}
                  </span>
                </div>
                <div className={`text-[9px] mb-2 ${
                  suggestion.type === 'selective' ? 'text-blue-600' : 'text-yellow-600'
                }`}>
                  {suggestion.reason}
                </div>
                <div className={`text-[10px] italic mb-3 leading-relaxed p-2 rounded ${
                  suggestion.type === 'selective' 
                    ? 'text-blue-800 bg-blue-100' 
                    : 'text-yellow-800 bg-yellow-100'
                }`}>
                  "{suggestion.keyExcerpt}"
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => onCaptureInsight(suggestion)}
                    className={`text-white text-[10px] px-3 py-1.5 rounded font-bold flex items-center gap-1 ${
                      suggestion.type === 'selective' 
                        ? 'bg-blue-500 hover:bg-blue-600' 
                        : 'bg-orange-500 hover:bg-orange-600'
                    }`}
                  >
                    📝 Capture {suggestion.type === 'selective' ? 'Extract' : 'Full'}
                  </button>
                  <button
                    onClick={() => onDismissSuggestion(suggestion.timestamp)}
                    className="bg-gray-300 hover:bg-gray-400 text-gray-700 text-[10px] px-2 py-1.5 rounded"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </>
    );
  }