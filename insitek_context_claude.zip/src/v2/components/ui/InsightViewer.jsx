// Removed Card components for minimal layout

export default function InsightViewer({ onClose, insight }) {
  if (!insight) {
    return (
      <div className="p-4 h-full flex flex-col text-xs text-gray-500">
        Select an insight from the list to view it.
      </div>
    );
  }

  return (
    <div className="p-4 h-full flex flex-col text-xs text-gray-700 leading-relaxed overflow-auto space-y-4">
      <div dangerouslySetInnerHTML={{ __html: insight.content }} />
      <div className="flex flex-wrap gap-1 mt-4">
        <span className="bg-green-100 text-green-600 text-[10px] px-2 py-[2px] rounded-full">{insight.channel}</span>
        {insight.tags.map((t)=>(
          <span key={t} className="bg-blue-100 text-blue-600 text-[10px] px-2 py-[2px] rounded-full">{t}</span>
        ))}
      </div>
    </div>
  );
}
