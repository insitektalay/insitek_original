/* src/components/ui/ImportPanel.jsx
   Updated with real-time progress tracking via WebSocket
   --------------------------------------------------------------- */
   import { useState, useRef, useMemo, useEffect } from "react";
   import { CheckIcon } from '@heroicons/react/20/solid';
   import { useImportContext } from '../../contexts/ImportContext.jsx';
   
   const MAX_ITEMS = 20;
   const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
   const WS_URL = API_URL.replace('http', 'ws');
   
   /* ----------------------------------------------------------------- */
   export default function ImportPanel({ onDone, isImporting, importYoutube }) {
     /* ----- persistent banner via context ----------------------------- */
     const { activeJob } = useImportContext();
     /* rows ----------------------------------------------------------- */
     const [items, setItems] = useState([
       { id: Date.now(), url: "", state: "idle", pct: 0, err: "", stage: "", importId: null, originalUrl: "" },
     ]);
     const wsRef = useRef(null);
     const timers = useRef({});
   
     /* WebSocket connection for real-time progress */
     useEffect(() => {
       const connectWebSocket = () => {
         try {
           wsRef.current = new WebSocket(WS_URL);
           
           wsRef.current.onopen = () => {
             console.log('WebSocket connected for progress updates');
           };
           
           wsRef.current.onmessage = (event) => {
             try {
               const data = JSON.parse(event.data);
               if (data.type === 'progress') {
                 const { importId, stage, progress } = data;
                 
                 setItems(prev => prev.map(item => {
                   if (item.importId === importId) {
                     // Ensure progress only goes forward, never backwards
                     const newProgress = Math.max(item.pct || 0, progress);
                     return { 
                       ...item, 
                       stage, 
                       pct: newProgress,
                       state: newProgress >= 100 ? "done" : "busy",
                       err: stage.startsWith('Error') ? stage : ""
                     };
                   }
                   return item;
                 }));
               }
             } catch (e) {
               console.error('Error parsing WebSocket message:', e);
             }
           };
           
           wsRef.current.onclose = () => {
             console.log('WebSocket disconnected, attempting reconnect...');
             setTimeout(connectWebSocket, 3000);
           };
           
           wsRef.current.onerror = (error) => {
             console.error('WebSocket error:', error);
           };
         } catch (error) {
           console.error('Failed to create WebSocket connection:', error);
         }
       };
       
       connectWebSocket();
       
       return () => {
         if (wsRef.current) {
           wsRef.current.close();
         }
       };
     }, []);
   
     /* derived stats -------------------------------------------------- */
     const stat = useMemo(() => {
       const total = items.filter((i) => i.url.trim()).length;
       const done  = items.filter((i) => i.state === "done").length;
       const fail  = items.filter((i) => i.state === "error").length;
       const pct   = total ? Math.round(((done + fail) / total) * 100) : 0;
       const finished = total && done + fail === total;
       return { total, done, fail, pct, finished };
     }, [items]);
   
     /* helpers -------------------------------------------------------- */
     const addRow = () =>
       setItems((p) =>
         p.length >= MAX_ITEMS
           ? p
           : [...p, { id: Date.now(), url: "", state: "idle", pct: 0, err: "", stage: "", importId: null, originalUrl: "" }]
       );
   
     const setUrl = (id, url) =>
       setItems((p) => p.map((it) => (it.id === id ? { ...it, url } : it)));
   
     /* Real import function using new WebSocket API ------------------- */
     const doImport = async (id, url) => {
       try {
         const importId = `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
         
         // Store original URL and clear input immediately when import starts
         setItems((p) =>
           p.map((it) => (it.id === id ? { ...it, state: "busy", pct: 0, importId, stage: "Starting", originalUrl: url, url: "" } : it))
         );
         
         // Subscribe to progress updates for this import
         if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
           wsRef.current.send(JSON.stringify({
             type: 'subscribe',
             importId
           }));
         }
         
         // Start the import
         const response = await fetch(`${API_URL}/api/transcribe-youtube`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ url, importId })
         });
         
         if (!response.ok) {
           const error = await response.json();
           throw new Error(error.error || 'Import failed');
         }
         
         // The progress will be handled by WebSocket messages
         console.log('Import started successfully');
         
       } catch (err) {
         setItems((p) =>
           p.map((it) =>
             it.id === id
               ? { ...it, state: "error", pct: 100, err: err.message, stage: "Error" }
               : it
           )
         );
       }
     };
   
     const importAll = async () => {
       const targets = items.filter((it) => it.url.trim());
       if (!targets.length) {
         alert("⚠️  Paste at least one YouTube URL first.");
         return;
       }
   
       // Process imports sequentially to avoid overwhelming the API
       for (const target of targets) {
         await doImport(target.id, target.url.trim());
         // Add a small delay between imports
         await new Promise(resolve => setTimeout(resolve, 1000));
       }
   
       // Wait for all imports to complete, then show results
       const checkComplete = () => {
         const currentItems = items.filter(i => i.url.trim());
         const completed = currentItems.filter(i => i.state === "done" || i.state === "error");
         
         if (completed.length === currentItems.length) {
           const finalStats = {
             done: currentItems.filter(i => i.state === "done").length,
             fail: currentItems.filter(i => i.state === "error").length
           };
           
           alert(`✅ ${finalStats.done} imported   ❌ ${finalStats.fail} failed`);
           onDone?.();
         } else {
           setTimeout(checkComplete, 2000);
         }
       };
       
       setTimeout(checkComplete, 2000);
     };
   
     /* Progress Stage Components ------------------------------------ */
     const getStageStatus = (stageName, currentStage, progress) => {
       const stages = [
         { name: 'Extracting', range: [0, 10] },
         { name: 'Downloading', range: [10, 30] }, 
         { name: 'Transcribing', range: [30, 85] },
         { name: 'Saving', range: [85, 100] }
       ];
       
       const stage = stages.find(s => s.name === stageName);
       if (!stage) return 'upcoming';
       
       // Special case: if progress is 100, all stages are complete
       if (progress >= 100) return 'complete';
       
       // A stage is complete when progress has moved beyond its range
       if (progress > stage.range[1]) return 'complete';
       
       // A stage is current if we're in its range or the current stage matches
       if ((progress >= stage.range[0] && progress <= stage.range[1]) || currentStage.includes(stageName)) {
         return 'current';
       }
       
       return 'upcoming';
     };
     
     const getStageProgress = (stageName, currentStage, overallProgress) => {
       const stages = [
         { name: 'Extracting', range: [0, 10] },
         { name: 'Downloading', range: [10, 30] }, 
         { name: 'Transcribing', range: [30, 85] },
         { name: 'Saving', range: [85, 100] }
       ];
       
       const stage = stages.find(s => s.name === stageName);
       if (!stage) return 0;
       
       const [min, max] = stage.range;
       
       if (overallProgress <= min) return 0;
       if (overallProgress >= max) return 100;
       
       // Calculate progress within this stage
       return Math.round(((overallProgress - min) / (max - min)) * 100);
     };
     
     function classNames(...classes) {
       return classes.filter(Boolean).join(' ');
     }
   
     const StageIndicators = ({ currentStage, overallProgress }) => {
       const stages = ['Extracting', 'Downloading', 'Transcribing', 'Saving'];
       
       return (
         <div className="mt-2 space-y-2">
           <nav aria-label="Progress">
             <ol role="list" className="flex items-center">
               {stages.map((stage, stepIdx) => {
                 const status = getStageStatus(stage, currentStage, overallProgress);
                 const stageProgress = getStageProgress(stage, currentStage, overallProgress);
                 
                 return (
                   <li key={stage} className="relative flex-1 flex items-center">
                     {/* Progress bar first */}
                     <div className="flex-1">
                       <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                         <div 
                           className="h-1 bg-indigo-600 transition-all duration-300 rounded-full"
                           style={{ width: `${stageProgress}%` }}
                         />
                       </div>
                     </div>
                     
                     {/* Circle at the end of progress bar */}
                     {status === 'complete' ? (
                       <div className="flex size-6 items-center justify-center rounded-full bg-indigo-600">
                         <CheckIcon aria-hidden="true" className="size-3 text-white" />
                       </div>
                     ) : status === 'current' ? (
                       <div className="flex size-6 items-center justify-center rounded-full border-2 border-indigo-600 bg-white">
                         <span aria-hidden="true" className="size-2 rounded-full bg-indigo-600" />
                       </div>
                     ) : (
                       <div className="flex size-6 items-center justify-center rounded-full border-2 border-gray-300 bg-white">
                         <span aria-hidden="true" className="size-2 rounded-full bg-transparent" />
                       </div>
                     )}
                   </li>
                 );
               })}
             </ol>
           </nav>
           
           {/* Stage labels and progress percentages only */}
           <div className="grid grid-cols-4 gap-2 text-[9px]">
             {stages.map((stage) => {
               const stageProgress = getStageProgress(stage, currentStage, overallProgress);
               const status = getStageStatus(stage, currentStage, overallProgress);
               
               return (
                 <div key={stage} className="text-center">
                   <div className={`font-medium ${status === 'current' ? 'text-indigo-600' : status === 'complete' ? 'text-indigo-600' : 'text-gray-400'}`}>
                     {stage}
                   </div>
                   <div className="mt-1 text-[8px] text-gray-500">
                     {stageProgress}%
                   </div>
                 </div>
               );
             })}
           </div>
         </div>
       );
     };
   
     /* ---------------------------------------------------------------- */
     return (
       <div className="p-4 text-xs space-y-4">
         {/* Persistent status banner */}
         {activeJob && (
           <div
             className={`rounded p-2 text-[11px] font-medium ${
               activeJob.state === 'DONE'
                 ? 'bg-green-100 text-green-800'
                 : activeJob.state === 'ERROR'
                 ? 'bg-red-100 text-red-800'
                 : 'bg-blue-100 text-blue-800'
             }`}
           >
             <div className="flex justify-between items-center gap-2">
               <span>
                 {activeJob.state === 'DONE'
                   ? 'Import completed'
                   : activeJob.state === 'ERROR'
                   ? activeJob.stage || 'Import error'
                   : `Importing…  ${activeJob.stage}`}
               </span>
               <span>{activeJob.progress ?? 0}%</span>
             </div>
             {activeJob.state !== 'ERROR' && (
               <div className="h-1 bg-white/40 rounded mt-1">
                 <div
                   className="h-1 bg-current rounded"
                   style={{ width: `${activeJob.progress}%` }}
                 />
               </div>
             )}
           </div>
         )}

         {/* per-row UI */}
         {items.map((it, idx) => (
           <div key={it.id} className="space-y-1">
             <input
               placeholder={`YouTube URL #${idx + 1}`}
               value={it.url}
               disabled={it.state === "busy" || isImporting}
               onChange={(e) => setUrl(it.id, e.target.value)}
               className="w-full p-2 border border-gray-200 rounded text-xs"
             />
           </div>
         ))}

         {/* controls */}
         <div className="flex gap-2 pt-2">
           <button
             onClick={addRow}
             disabled={items.length >= MAX_ITEMS || isImporting}
             className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded text-sm disabled:opacity-50"
           >
             ＋ Add video
           </button>

           <button
             onClick={importAll}
             disabled={isImporting}
             className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-1 rounded text-sm disabled:opacity-50"
           >
             {isImporting ? "Importing..." : "Import"}
           </button>
         </div>

         <div className="text-[10px] text-gray-400 mt-1">
           You can queue up to {MAX_ITEMS} videos.
         </div>

         {/* Show importing videos below the queue text */}
         {items.filter(it => it.state !== "idle").map((it) => (
           <div key={`importing-${it.id}`} className="space-y-2 border-t pt-3 mt-3">
             {/* Show URL being imported */}
             {it.originalUrl && (
               <div className="text-[10px] text-gray-600 truncate">
                 {it.originalUrl}
               </div>
             )}

             {/* Stage indicators for both busy and completed states */}
             {(it.state === "busy" || it.state === "done") && it.stage && (
               <StageIndicators currentStage={it.stage} overallProgress={it.pct} />
             )}
             
             {/* Error display */}
             {it.state === "error" && (
               <div className="text-red-500 text-[10px] break-all">
                 {it.err}
               </div>
             )}
           </div>
         ))}
       </div>
     );
   }