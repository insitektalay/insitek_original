/*  src/v2/components/ui/TranscriptList.jsx
    --------------------------------------------------------------
    Row click (or right-arrow click) → onOpenViewer(id)
    Chat button                    → onChat(id)
    3-dot menu                     → onDelete(id)
*/

import { useEffect, useState } from 'react'
import { EllipsisVerticalIcon, ChevronRightIcon } from '@heroicons/react/24/outline'

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3001'

export default function TranscriptList({
  onOpenViewer,   // (id) => parent sets selected + jumps to viewer tab
  onChat   = () => {},
  onDelete = () => {},
}) {
  const [rows, setRows] = useState([])

  /* fetch once */
  useEffect(() => {
    ;(async () => {
      try {
        const r = await fetch(`${API_URL}/api/transcripts`)
        if (!r.ok) throw new Error(r.statusText)
        setRows(await r.json())
      } catch (e) {
        console.error('load transcripts', e)
        setRows([])
      }
    })()
  }, [])

  const handleRowClick = (transcriptId) => {
    onOpenViewer(transcriptId)
  }

  const handleChatClick = (e, transcriptId) => {
    e.stopPropagation()
    onChat(transcriptId)
  }

  return (
    <ul role="list" className="divide-y divide-gray-100">
      {rows.map((t) => (
        <li
          key={t.id}
          className="relative cursor-pointer py-5 hover:bg-gray-50"
          onClick={() => handleRowClick(t.id)}
        >
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="mx-auto flex max-w-6xl justify-between gap-x-6">
              {/* left block */}
              <div className="flex min-w-0 gap-x-4">
                <Menu
                  onDelete={() => onDelete(t.id)}
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="min-w-0 flex-auto">
                  <p className="text-sm/6 font-semibold text-gray-900">{t.title}</p>
                  <p className="mt-0.5 text-xs/5 text-gray-500">{fmt(t.uploadDate)}</p>
                  <p className="mt-1 truncate text-xs/5 text-gray-500">{t.description}</p>
                </div>
              </div>

              {/* right block */}
              <div className="flex shrink-0 items-end gap-x-4">
                <div className="flex flex-col items-end">
                  <p className="text-xs font-medium text-gray-900">
                    {t.channel} / {t.source}
                  </p>
                  <button
                    className="mt-1 self-center rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500"
                    onClick={(e) => handleChatClick(e, t.id)}
                  >
                    Chat
                  </button>
                </div>
                <ChevronRightIcon
                  aria-hidden="true"
                  className="size-5 text-gray-400 cursor-pointer hover:text-gray-600"
                />
              </div>
            </div>
          </div>
        </li>
      ))}
    </ul>
  )
}

/* three-dot delete menu */
function Menu({ onDelete, onClick }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button
        onClick={(e) => {
          onClick?.(e)
          setOpen(!open)
        }}
        className="rounded-full p-1.5 hover:bg-gray-200"
      >
        <EllipsisVerticalIcon className="size-5 text-gray-400" />
      </button>

      {open && (
        <div className="absolute left-0 z-10 mt-1 w-28 rounded-md bg-white py-1 shadow-lg ring-1 ring-black/5">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setOpen(false)
              onDelete?.()
            }}
            className="block w-full px-4 py-1.5 text-left text-[11px] text-gray-700 hover:bg-gray-100"
          >
            Delete
          </button>
        </div>
      )}
    </div>
  )
}

/* date formatter */
function fmt(iso) {
  if (!iso) return ''
  const ts = Date.parse(iso)
  if (Number.isNaN(ts)) return ''
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(ts))
}