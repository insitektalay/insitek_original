// src/components/ui/PodcastImportPanel.jsx
import { useEffect, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
const MAX_ITEMS = 20;

export default function PodcastImportPanel({ onDone }) {
  // Feed and episode states
  const [feedUrl, setFeedUrl] = useState("");
  const [isLoadingFeed, setIsLoadingFeed] = useState(false);
  const [podcastInfo, setPodcastInfo] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [selectedEpisodes, setSelectedEpisodes] = useState([]);
  
  // Import progress states
  const [importing, setImporting] = useState(false);
  const [importStatus, setImportStatus] = useState([]);

  // Load podcast feed
  const loadPodcastFeed = async () => {
    if (!feedUrl.trim()) {
      alert("Please enter a podcast RSS feed URL");
      return;
    }

    setIsLoadingFeed(true);
    try {
      const response = await fetch(`${API_URL}/api/podcast-feed`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: feedUrl.trim() }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || `HTTP error ${response.status}`);
      }

      const data = await response.json();
      setPodcastInfo({
        title: data.title,
        description: data.description,
        imageUrl: data.imageUrl,
        author: data.author
      });
      setEpisodes(data.episodes);
      setSelectedEpisodes([]);
    } catch (error) {
      console.error("Failed to load podcast feed:", error);
      alert(`Failed to load podcast feed: ${error.message}`);
    } finally {
      setIsLoadingFeed(false);
    }
  };

  // Handle episode selection
  const toggleEpisodeSelection = (episodeId) => {
    setSelectedEpisodes(prev => {
      if (prev.includes(episodeId)) {
        return prev.filter(id => id !== episodeId);
      } else {
        // Limit selection to MAX_ITEMS
        if (prev.length >= MAX_ITEMS) {
          alert(`You can only select up to ${MAX_ITEMS} episodes at once.`);
          return prev;
        }
        return [...prev, episodeId];
      }
    });
  };

  // Handle batch import
  const importSelected = async () => {
    if (selectedEpisodes.length === 0) {
      alert("Please select at least one episode to import");
      return;
    }

    setImporting(true);
    setImportStatus(selectedEpisodes.map(id => ({
      id,
      status: "pending",
      progress: 0,
      error: null
    })));

    // Process episodes one by one
    for (const episodeId of selectedEpisodes) {
      try {
        // Update status to processing
        setImportStatus(prev => 
          prev.map(item => 
            item.id === episodeId 
              ? { ...item, status: "processing", progress: 10 } 
              : item
          )
        );

        // Start import
        const episode = episodes.find(ep => ep.id === episodeId);
        const response = await fetch(`${API_URL}/api/transcribe-podcast`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            url: episode.audioUrl,
            title: episode.title,
            publishDate: episode.publishDate,
            podcastName: podcastInfo.title
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || `HTTP error ${response.status}`);
        }

        // Simulate progress updates
        for (let progress = 20; progress < 90; progress += 10) {
          setImportStatus(prev => 
            prev.map(item => 
              item.id === episodeId 
                ? { ...item, progress } 
                : item
            )
          );
          await new Promise(resolve => setTimeout(resolve, 500));
        }

        // Update status to complete
        setImportStatus(prev => 
          prev.map(item => 
            item.id === episodeId 
              ? { ...item, status: "complete", progress: 100 } 
              : item
          )
        );
      } catch (error) {
        console.error(`Failed to import episode ${episodeId}:`, error);
        setImportStatus(prev => 
          prev.map(item => 
            item.id === episodeId 
              ? { ...item, status: "error", progress: 100, error: error.message } 
              : item
          )
        );
      }
    }

    setImporting(false);
    onDone?.(); // Refresh transcript list
  };

  // Format date
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString();
    } catch (e) {
      return "Unknown date";
    }
  };

  // Truncate text
  const truncate = (text, maxLength = 100) => {
    if (!text || text.length <= maxLength) return text;
    return text.slice(0, maxLength) + "...";
  };

  return (
    <div className="p-4 text-xs space-y-4">
      {/* Feed URL input */}
      <div className="space-y-2">
        <div className="flex space-x-2">
          <input
            type="text"
            value={feedUrl}
            onChange={(e) => setFeedUrl(e.target.value)}
            placeholder="Enter podcast RSS feed URL"
            className="flex-1 border rounded px-2 py-1.5 text-xs"
            disabled={isLoadingFeed || importing}
          />
          <button
            onClick={loadPodcastFeed}
            disabled={isLoadingFeed || importing}
            className={`px-3 py-1.5 rounded text-white text-xs font-bold ${
              isLoadingFeed || importing
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500"
            }`}
          >
            {isLoadingFeed ? "Loading..." : "Load Feed"}
          </button>
        </div>
        
        <div className="text-[10px] text-gray-500">
          Example: https://feeds.megaphone.fm/darknetdiaries
        </div>
      </div>

      {/* Podcast info */}
      {podcastInfo && (
        <div className="border rounded p-3 space-y-2 bg-gray-50">
          <div className="font-bold">{podcastInfo.title}</div>
          {podcastInfo.author && (
            <div className="text-gray-600">By: {podcastInfo.author}</div>
          )}
          <div className="text-[10px] text-gray-600">
            {truncate(podcastInfo.description, 200)}
          </div>
        </div>
      )}

      {/* Episode selection */}
      {episodes.length > 0 && (
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <div className="font-bold">
              Episodes ({episodes.length})
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedEpisodes(episodes.slice(0, MAX_ITEMS).map(ep => ep.id))}
                disabled={importing}
                className="text-[10px] bg-indigo-600 hover:bg-indigo-500 text-white px-2 py-1 rounded"
              >
                Select First {MAX_ITEMS}
              </button>
              <button
                onClick={() => setSelectedEpisodes([])}
                disabled={importing}
                className="text-[10px] bg-indigo-600 hover:bg-indigo-500 text-white px-2 py-1 rounded"
              >
                Clear
              </button>
            </div>
          </div>
          
          <div className="max-h-[40vh] overflow-y-auto border rounded">
            {episodes.map((episode) => {
              const isSelected = selectedEpisodes.includes(episode.id);
              const importItem = importStatus.find(item => item.id === episode.id);
              
              return (
                <div 
                  key={episode.id}
                  className={`p-2 border-b last:border-b-0 hover:bg-gray-50 ${
                    isSelected ? "bg-blue-50" : ""
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleEpisodeSelection(episode.id)}
                      disabled={importing && !isSelected}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-[11px]">{episode.title}</div>
                      <div className="text-[10px] text-gray-500">
                        {formatDate(episode.publishDate)} • {episode.duration || "Unknown duration"}
                      </div>
                      
                      {importItem && (
                        <div className="mt-1">
                          <div className="h-1.5 w-full bg-gray-200 rounded">
                            <div
                              className={`h-full rounded ${
                                importItem.status === "error" 
                                  ? "bg-red-500" 
                                  : importItem.status === "complete"
                                  ? "bg-green-500"
                                  : "bg-blue-500"
                              }`}
                              style={{ width: `${importItem.progress}%` }}
                            />
                          </div>
                          {importItem.status === "error" && (
                            <div className="text-[9px] text-red-500 mt-1">
                              Error: {importItem.error}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Import button */}
      {episodes.length > 0 && (
        <div className="space-y-2">
          <button
            onClick={importSelected}
            disabled={selectedEpisodes.length === 0 || importing}
            className={`w-full py-2 rounded text-white text-xs font-bold ${
              selectedEpisodes.length === 0 || importing
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500"
            }`}
          >
            {importing
              ? "Importing..."
              : `Import ${selectedEpisodes.length} Selected Episode${selectedEpisodes.length !== 1 ? "s" : ""}`}
          </button>
          
          <div className="text-[10px] text-gray-500 text-center">
            Selected: {selectedEpisodes.length} / {MAX_ITEMS} maximum
          </div>
        </div>
      )}
    </div>
  );
}