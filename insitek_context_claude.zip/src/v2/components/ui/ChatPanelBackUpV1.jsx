// src/v2/components/ChatPanel.jsx
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { useInsightExtraction } from '../../hooks/useInsightExtraction';
import { useTransferFunctions } from '../../hooks/useTransferFunctions';
import InsightSuggestions from './InsightSuggestions';
import ManualCaptureControls from './ManualCaptureControls';

export default function ChatPanel({
  onClose,
  transcript,
  onSuggestPrompts,
  onCaptureInsight,
}) {
  /* ─────────── state ─────────── */
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);

  /* ─────────── custom hooks ─────────── */
  const {
    insightSuggestions,
    runInsightDetection,
    handleCaptureInsight,
    dismissInsightSuggestion,
    clearInsightSuggestions,
  } = useInsightExtraction();

  const {
    transferLastResponse,
    transferSelectedText,
    transferCondensedResponse,
  } = useTransferFunctions();

  /* ─────────── reset when transcript changes ─────────── */
  useEffect(() => {
    setMessages([]);
    setInput('');
    clearInsightSuggestions();
  }, [transcript?.id]);

  /* ─────────── core send() ─────────── */
  async function send(injectedText = null) {
    const content = injectedText ?? input.trim();
    if (!content || !transcript) return;

    const userMsg = { role: 'user', content };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setThinking(true);

    const systemPrompt = `You are an expert assistant. Use this transcript as reference:\n${transcript.text}`;
    const prompt = `${systemPrompt}\n\nUser: ${content}\nAI:`;

    try {
      const res = await fetch('http://localhost:8080/completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          temperature: 0.7,
          stop: ['User:', 'AI:'],
          n_predict: 512,
          stream: true,
        }),
      });

      if (!res.ok || !res.body) throw new Error();

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullText = '';

      const newMessageIndex = messages.length + 1;
      setMessages((m) => [...m, { role: 'assistant', content: '' }]);

      let buffer = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const payload = line.slice(6).trim();
          if (payload === '[DONE]') break;

          try {
            const parsed = JSON.parse(payload);
            if (parsed.content) {
              fullText += parsed.content;
              setMessages((m) =>
                m.map((msg, i) =>
                  i === m.length - 1 && msg.role === 'assistant'
                    ? { ...msg, content: fullText }
                    : msg,
                ),
              );
            }
          } catch {
            /* ignored chunk */
          }
        }
      }

      /* ── prompt suggestions ── */
      if (onSuggestPrompts) {
        const chatText = [
          ...messages,
          userMsg,
          { role: 'assistant', content: fullText },
        ]
          .map((m) => `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`)
          .join('\n');
        onSuggestPrompts(chatText);
      }

      /* ── smart insight detection ── */
      runInsightDetection(fullText, newMessageIndex);
    } catch {
      alert('AI request failed.');
    }
    setThinking(false);
  }

  /* ─────────── prompt-deck bridge ─────────── */
  useEffect(() => {
    const handler = (e) => {
      if (typeof e.detail === 'string') {
        setInput(e.detail);
        setTimeout(() => send(e.detail), 0);
      }
    };
    window.addEventListener('promptdeck:submit', handler);
    return () => window.removeEventListener('promptdeck:submit', handler);
  }, [send]); // listener re-binds whenever send() changes

  /* ─────────── helpers ─────────── */
  const renderMsg = (txt) =>
    txt
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .split('\n')
      .map((l, i) => <p key={i} dangerouslySetInnerHTML={{ __html: l }} />);

  /* ─────────── transfers & captures ─────────── */
  const handleInsightCapture = (s) => handleCaptureInsight(s, onCaptureInsight);

  /* ─────────── render ─────────── */
  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
        <span>Chat</span>
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >
          ×
        </button>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-4">
        {!transcript ? (
          <div className="bg-gray-100 p-2 italic rounded">
            No transcript selected.
          </div>
        ) : (
          <>
            <div className="bg-gray-100 p-2 rounded text-[11px]">
              <strong>{transcript.title}</strong>
              <span className="ml-2 bg-green-100 text-green-600 px-2 py-[2px] rounded-full">
                {transcript.channel}
              </span>
            </div>

            {messages.map((m, i) => (
              <div key={i} className="relative">
                <div
                  className={
                    m.role === 'user' ? 'text-blue-600' : 'text-gray-700'
                  }
                >
                  <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
                  {m.role === 'assistant' ? renderMsg(m.content) : m.content}
                </div>

                {m.role === 'assistant' && (
                  <InsightSuggestions
                    messageIndex={i}
                    insightSuggestions={insightSuggestions}
                    onCaptureInsight={handleInsightCapture}
                    onDismissSuggestion={dismissInsightSuggestion}
                  />
                )}
              </div>
            ))}

            {thinking && (
              <div className="italic text-gray-400">AI is thinking…</div>
            )}

            <ManualCaptureControls
              messages={messages}
              onTransferLastResponse={() =>
                transferLastResponse(messages, onCaptureInsight)
              }
              onTransferSelectedText={() =>
                transferSelectedText(onCaptureInsight)
              }
              onTransferCondensedResponse={(lvl) =>
                transferCondensedResponse(
                  messages,
                  lvl,
                  onCaptureInsight,
                )
              }
            />
          </>
        )}
      </CardContent>

      <div className="p-2 border-t flex">
        <input
          className="flex-1 border rounded px-2 py-1 text-xs border-gray-300"
          placeholder="Type your question…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          disabled={!transcript}
        />
        <button
          onClick={() => send()}
          disabled={!transcript || thinking}
          className="ml-2 bg-blue-500 hover:bg-blue-600 text-white rounded text-xs px-4"
        >
          Send
        </button>
      </div>
    </Card>
  );
}