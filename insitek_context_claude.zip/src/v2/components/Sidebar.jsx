// src/v2/components/Sidebar.jsx
import { useNavigation } from '../contexts/NavigationContext'
import { ChevronLeftIcon, ChevronRightIcon } from '@heroicons/react/24/outline'
import {
  ImportIcon,
  TranscriptsIcon,
  ChatIcon,
  InsightsIcon,
  ImportIconInactive,
  TranscriptsIconInactive,
  ChatIconInactive,
  InsightsIconInactive,
} from './CustomIcons'

const navigation = [
  { name: 'Import', icon: ImportIcon, iconInactive: ImportIconInactive },
  { name: 'Transcripts', icon: TranscriptsIcon, iconInactive: TranscriptsIconInactive },
  { name: 'Chat', icon: ChatIcon, iconInactive: ChatIconInactive },
  { name: 'Insights', icon: InsightsIcon, iconInactive: InsightsIconInactive },
]

const cn = (...c) => c.filter(Boolean).join(' ')

export default function Sidebar() {
  const { page, collapsed, setCollapsed, setPage, setTab, pageTabs } = useNavigation()

  return (
    <aside className={cn(
      'fixed inset-y-0 z-50 flex flex-col bg-indigo-600 transition-all duration-300',
      collapsed ? 'w-16' : 'w-72'
    )}>
      <div className={cn(
        'flex grow flex-col overflow-y-auto transition-all duration-300',
        collapsed ? 'gap-y-4 px-1' : 'gap-y-5 px-6'
      )}>
        {/* logo + toggle */}
        <div className="relative flex h-16 shrink-0 items-center">
          {!collapsed && (
            <img
              src="https://tailwindcss.com/plus-assets/img/logos/mark.svg?color=white"
              alt="logo"
              className="h-8 w-auto"
            />
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="absolute right-0 rounded p-1 text-indigo-200 hover:bg-indigo-700 hover:text-white"
          >
            {collapsed ? (
              <ChevronRightIcon className="size-5" />
            ) : (
              <ChevronLeftIcon className="size-5" />
            )}
          </button>
        </div>

        {/* nav */}
        <nav className="flex flex-1 flex-col">
          <ul role="list" className="flex flex-1 flex-col gap-y-7">
            <li>
              <ul role="list" className="-mx-2 space-y-1">
                {navigation.map((n) => {
                  const active = n.name === page
                  const Icon = active ? n.icon : n.iconInactive
                  return (
                    <li key={n.name}>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault()
                          setPage(n.name)
                          setTab(pageTabs[n.name][0])
                        }}
                        className={cn(
                          active
                            ? 'bg-indigo-700 text-white'
                            : 'text-indigo-200 hover:bg-indigo-700 hover:text-white',
                          'group flex rounded-md p-2 text-sm/6 font-semibold',
                          collapsed ? 'justify-center' : 'gap-x-3'
                        )}
                      >
                        <Icon className="size-6 shrink-0" />
                        <span className={collapsed ? 'sr-only' : ''}>
                          {n.name}
                        </span>
                      </a>
                    </li>
                  )
                })}
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  )
}