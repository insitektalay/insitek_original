// src/v2/components/MainContent.jsx
import { useNavigation } from '../contexts/NavigationContext'
import PanelRouter from './PanelRouter'

const cn = (...c) => c.filter(Boolean).join(' ')

export default function MainContent() {
  const { page, tab, collapsed, setTab, pageTabs } = useNavigation()
  const tabs = pageTabs[page]

  return (
    <main className={cn(
      'flex-1 flex flex-col transition-[padding-left] duration-300',
      collapsed ? 'pl-16' : 'pl-72'
    )}>
      {/* Fixed header with tabs */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="px-4 sm:px-6 lg:px-8 py-5 sm:pb-0">
          <h3 className="text-base font-semibold text-gray-900">{page}</h3>
          {/* tabs */}
          <div className="mt-3 sm:mt-4">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              {tabs.map((label) => (
                <a
                  key={label}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setTab(label)
                  }}
                  className={cn(
                    label === tab
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700',
                    'whitespace-nowrap border-b-2 px-1 pb-4 text-sm font-medium'
                  )}
                >
                  {label}
                </a>
              ))}
            </nav>
          </div>
        </div>
      </div>

      {/* Scrollable content area */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 sm:px-6 lg:px-8 py-6">
          <PanelRouter />
        </div>
      </div>
    </main>
  )
}