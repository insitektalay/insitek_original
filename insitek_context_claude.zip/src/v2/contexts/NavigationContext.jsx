// src/v2/contexts/NavigationContext.jsx
import { createContext, useContext, useState } from 'react'

const NavigationContext = createContext()

export const useNavigation = () => {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

const pageTabs = {
  Import: ['Youtube video', 'Youtube channel', 'RSS podcast'],
  Transcripts: ['Transcripts', 'Transcript viewer'],
  Chat: ['Chat', 'Summary', 'Prompt Deck', 'Source context'],
  Insights: ['Insight editor', 'Insight list', 'Insight viewer'],
}

export function NavigationProvider({ children }) {
  const [collapsed, setCollapsed] = useState(false)
  const [page, setPage] = useState('Import')
  const [tab, setTab] = useState(pageTabs.Import[0]) // default first tab

  const navigateTo = (newPage, newTab = null) => {
    setPage(newPage)
    if (newTab) {
      setTab(newTab)
    } else {
      // Set default tab for the page
      setTab(pageTabs[newPage][0])
    }
  }

  return (
    <NavigationContext.Provider value={{
      collapsed,
      setCollapsed,
      page,
      setPage,
      tab,
      setTab,
      navigateTo,
      pageTabs
    }}>
      {children}
    </NavigationContext.Provider>
  )
}