// src/v2/hooks/useTransferFunctions.js

export function useTransferFunctions() {

    // Manual transfer functions
    const transferLastResponse = (messages, onCaptureInsight) => {
      const lastAIMessage = [...messages].reverse().find(m => m.role === 'assistant');
      if (!lastAIMessage) return alert('No AI response to transfer');
  
      onCaptureInsight?.({
        content: lastAIMessage.content,
        suggestedTitle: "Full Response from Chat",
        source: 'chat_manual_full',
        timestamp: Date.now()
      });
    };
  
    const transferSelectedText = (onCaptureInsight) => {
      const selectedText = window.getSelection().toString().trim();
      if (!selectedText) return alert('Please select some text first');
      if (selectedText.length < 20) return alert('Please select more text');
  
      onCaptureInsight?.({
        content: selectedText,
        suggestedTitle: "Selected Text from Chat",
        source: 'chat_manual_selected',
        timestamp: Date.now()
      });
    };
  
    // Condensed transfer functions
    const transferCondensedResponse = async (messages, compressionLevel, onCaptureInsight) => {
      const lastAIMessage = [...messages].reverse().find(m => m.role === 'assistant');
      if (!lastAIMessage) return alert('No AI response to condense');
  
      try {
        const compressionPrompts = {
          0.75: "Condense this response to 75% of its length while keeping all key points:",
          0.5: "Condense this response to 50% of its length, keeping only the most important information:",
          0.25: "Create a very concise summary of this response (25% length), including only the essential points:"
        };
  
        const prompt = `${compressionPrompts[compressionLevel]}
  
  "${lastAIMessage.content}"
  
  Condensed version:`;
  
        const response = await fetch("http://localhost:8080/completion", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt,
            temperature: 0.3,
            n_predict: Math.floor(lastAIMessage.content.length * compressionLevel * 0.8),
            stop: ["Condensed version:", "Original:", "\n\n"]
          })
        });
  
        if (!response.ok) throw new Error("Condensing failed");
  
        const data = await response.json();
        const condensedContent = (data.content || data.completion || "").trim();
  
        // Clean up any weird characters or artifacts
        const cleanContent = condensedContent
          .replace(/\|+/g, '') // Remove pipe characters
          .replace(/\s+/g, ' ') // Replace multiple spaces with single space
          .replace(/["']/g, '') // Remove extra quotes
          .trim();
  
        if (cleanContent && cleanContent.length > 20) {
          onCaptureInsight?.({
            content: cleanContent,
            suggestedTitle: `Condensed Insight (${Math.round(compressionLevel * 100)}%)`,
            source: `chat_condensed_${compressionLevel}`,
            timestamp: Date.now()
          });
        } else {
          alert("Failed to generate condensed version");
        }
      } catch (error) {
        console.error("Condensing error:", error);
        alert("Failed to condense response");
      }
    };
  
    return {
      transferLastResponse,
      transferSelectedText,
      transferCondensedResponse
    };
  }