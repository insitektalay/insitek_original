// src/v2/hooks/useInsightExtraction.js
// ⓘ Changes:
//    • clearInsightSuggestions is now memo-ised with useCallback
// ---------------------------------------------------------------

import { useState, useCallback } from 'react';

export function useInsightExtraction() {
  const [insightSuggestions, setInsightSuggestions] = useState([]);

  /* ──────────── helpers ──────────── */

  // Stable - clears all queued suggestions
  const clearInsightSuggestions = useCallback(() => {
    setInsightSuggestions([]);
  }, []);

  // 🤖 SMART SELECTIVE INSIGHT EXTRACTION
  const extractSelectiveInsights = async (messageContent, messageIndex) => {
    if (!messageContent || messageContent.length < 200) return;

    try {
      const prompt = `Extract 1-3 specific valuable insights from this AI response. Find the most insightful sentences or short paragraphs.

Response:
"${messageContent}"

For each insight found, format as:
INSIGHT_START
[extract the specific insightful text - 1-3 sentences only]
INSIGHT_END
TITLE: [short descriptive title for this insight]
REASON: [why this specific text is valuable]

Only extract text that contains actual insights, analysis, or key information. Skip filler text.`;

      const response = await fetch('http://localhost:8080/completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          temperature: 0.2,
          n_predict: 400,
          stop: ['Response:', 'Extract'],
        }),
      });

      if (!response.ok) return;

      const data = await response.json();
      const analysis = data.content || data.completion || '';

      // Parse extracted insights
      const insightMatches = analysis.match(
        /INSIGHT_START\s*(.*?)\s*INSIGHT_END\s*TITLE:\s*(.*?)\s*REASON:\s*(.*?)(?=INSIGHT_START|$)/gs,
      );

      if (insightMatches?.length) {
        insightMatches.forEach((match, index) => {
          const insightText = match.match(/INSIGHT_START\s*(.*?)\s*INSIGHT_END/s)?.[1]?.trim();
          const title = match.match(/TITLE:\s*(.*?)(?=\s*REASON)/s)?.[1]?.trim();
          const reason = match.match(/REASON:\s*(.*?)$/s)?.[1]?.trim();

          if (insightText && insightText.length > 20) {
            const suggestion = {
              messageIndex,
              content: insightText,
              reason: reason || 'Contains specific insight',
              suggestedTitle: title || 'Extracted Insight',
              keyExcerpt:
                insightText.length > 100 ? `${insightText.substring(0, 100)}…` : insightText,
              type: 'selective',
              timestamp: Date.now() + index,
            };

            setInsightSuggestions((prev) => [...prev, suggestion]);
          }
        });
      }
    } catch (error) {
      console.error('Selective insight extraction error:', error);
    }
  };

  // 📝 KEYWORD-BASED FULL-RESPONSE DETECTION (fallback)
  const detectFullResponseInsight = (messageContent, messageIndex) => {
    const insightKeywords = [
      'summary',
      'analysis',
      'implications',
      'examples',
      'explanation',
      'key points',
      'important',
      'demonstrates',
      'reveals',
      'consequences',
    ];

    const lowerContent = messageContent.toLowerCase();
    const foundKeywords = insightKeywords.filter((kw) => lowerContent.includes(kw));

    if (foundKeywords.length >= 2 && messageContent.length > 300) {
      const suggestion = {
        messageIndex,
        content: messageContent,
        reason: `Full response contains ${foundKeywords.length} insight indicators`,
        suggestedTitle: 'Complete Analysis from Chat',
        keyExcerpt: `${messageContent.substring(0, 120)}…`,
        type: 'full_response',
        timestamp: Date.now() + 1000,
      };

      setInsightSuggestions((prev) => [...prev, suggestion]);
    }
  };

  /* ──────────── public API ──────────── */

  const runInsightDetection = (messageContent, messageIndex) => {
    // First: selective extraction
    setTimeout(() => {
      extractSelectiveInsights(messageContent, messageIndex);

      // Second: keyword fallback
      setTimeout(() => {
        detectFullResponseInsight(messageContent, messageIndex);
      }, 1000);
    }, 500);
  };

  const handleCaptureInsight = (suggestion, onCaptureInsight) => {
    onCaptureInsight?.({
      content: suggestion.content,
      suggestedTitle: suggestion.suggestedTitle,
      source: suggestion.type === 'selective' ? 'chat_smart_selective' : 'chat_smart_full',
      timestamp: suggestion.timestamp,
    });
    setInsightSuggestions((prev) => prev.filter((s) => s.timestamp !== suggestion.timestamp));
  };

  const dismissInsightSuggestion = (timestamp) => {
    setInsightSuggestions((prev) => prev.filter((s) => s.timestamp !== timestamp));
  };

  return {
    insightSuggestions,
    runInsightDetection,
    handleCaptureInsight,
    dismissInsightSuggestion,
    clearInsightSuggestions,
  };
}
