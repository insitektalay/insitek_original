import { useState } from 'react';
import Layout from "./components/Layout"; // Your current V1 UI
import LayoutV2 from "./v2/components/Layout"; // Your new V2 UI

function App() {
  const [useV2UI, setUseV2UI] = useState(false);
  
  return (
    <div className="h-full">  {/* Add h-full class here */}
      {/* Toggle button - positioned in top-right corner */}
      <button 
        onClick={() => setUseV2UI(!useV2UI)}
        style={{ 
          position: 'fixed', 
          top: '10px', 
          right: '10px', 
          zIndex: 1000,
          padding: '8px 12px',
          backgroundColor: useV2UI ? '#10b981' : '#3b82f6',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '12px',
          fontWeight: '500'
        }}
      >
        {useV2UI ? 'Switch to V1' : 'Switch to V2'}
      </button>
      
      {/* Render current or new UI based on toggle */}
      {useV2UI ? (
        <LayoutV2 />
      ) : (
        <Layout />
      )}
    </div>
  );
}

export default App;