/* src/components/ui/ImportPanel.jsx
   --------------------------------------------------------------- */
   import { useState, useRef, useMemo } from "react";
   import { Card, CardContent, CardHeader } from "@/components/ui/card";
   
   const API_URL   = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
   const MAX_ITEMS = 20;
   
   /* ----------------------------------------------------------------- */
   export default function ImportPanel({ onClose, onDone }) {
     /* rows ----------------------------------------------------------- */
     const [items, setItems] = useState([
       { id: Date.now(), url: "", state: "idle", pct: 0, err: "" },
     ]);
     const timers = useRef({});          // id → interval handle
   
     /* derived stats -------------------------------------------------- */
     const stat = useMemo(() => {
       const total = items.filter((i) => i.url.trim()).length;
       const done  = items.filter((i) => i.state === "done").length;
       const fail  = items.filter((i) => i.state === "error").length;
       const pct   = total ? Math.round(((done + fail) / total) * 100) : 0;
       const finished = total && done + fail === total;
       return { total, done, fail, pct, finished };
     }, [items]);
   
     /* helpers -------------------------------------------------------- */
     const addRow = () =>
       setItems((p) =>
         p.length >= MAX_ITEMS
           ? p
           : [...p, { id: Date.now(), url: "", state: "idle", pct: 0, err: "" }]
       );
   
     const setUrl = (id, url) =>
       setItems((p) => p.map((it) => (it.id === id ? { ...it, url } : it)));
   
     const startFake = (id) => {
       timers.current[id] = setInterval(() => {
         setItems((p) =>
           p.map((it) =>
             it.id === id && it.state === "busy"
               ? { ...it, pct: Math.min(it.pct + 3, 92) }
               : it
           )
         );
       }, 180);
     };
     const stopFake = (id) => {
       clearInterval(timers.current[id]);
       delete timers.current[id];
     };
   
     /* actual POST ---------------------------------------------------- */
     const doImport = async (id, url) => {
       try {
         const r = await fetch(`${API_URL}/api/transcribe-youtube`, {
           method: "POST",
           headers: { "Content-Type": "application/json" },
           body: JSON.stringify({ url }),
         });
         if (!r.ok) {
           const { error } = await r.json().catch(() => ({}));
           throw new Error(error || `HTTP ${r.status}`);
         }
         setItems((p) =>
           p.map((it) => (it.id === id ? { ...it, state: "done", pct: 100 } : it))
         );
       } catch (err) {
         setItems((p) =>
           p.map((it) =>
             it.id === id
               ? { ...it, state: "error", pct: 100, err: err.message }
               : it
           )
         );
       } finally {
         stopFake(id);
       }
     };
   
     const importAll = async () => {
       const targets = items.filter((it) => it.url.trim());
       if (!targets.length) {
         alert("⚠️  Paste at least one YouTube URL first.");
         return;
       }
   
       /* mark busy and start fake bars */
       setItems((p) =>
         p.map((it) => {
           if (!it.url.trim()) return it;
           startFake(it.id);
           return { ...it, state: "busy", pct: 0 };
         })
       );
   
       await Promise.all(targets.map((t) => doImport(t.id, t.url.trim())));
   
       alert(`✅ ${stat.done} imported   ❌ ${stat.fail} failed`);
       onDone?.();           // refresh TranscriptList
     };
   
     /* ---------------------------------------------------------------- */
     return (
       <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
         {/* header */}
         <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
           <span>Import YouTube Transcript</span>
           <button
             onClick={onClose}
             className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
           >
             ×
           </button>
         </CardHeader>
   
         {/* body */}
         <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-4">
           {/* global bar */}
           {stat.total > 0 && (
             <div className="space-y-1">
               <div className="w-full bg-gray-200 rounded h-2">
                 <div
                   className={`h-full ${
                     stat.finished ? "bg-green-600" : "bg-blue-500"
                   } transition-all`}
                   style={{ width: `${stat.pct}%` }}
                 />
               </div>
               <div className="text-[10px] text-gray-600">
                 {stat.done + stat.fail}/{stat.total} completed
               </div>
             </div>
           )}
   
           {/* per-row UI */}
           {items.map((it, idx) => (
             <div key={it.id} className="space-y-1">
               <input
                 placeholder={`YouTube URL #${idx + 1}`}
                 value={it.url}
                 disabled={it.state === "busy"}
                 onChange={(e) => setUrl(it.id, e.target.value)}
                 className="w-full p-2 border border-gray-200 rounded text-xs"
               />
   
               {it.state !== "idle" && (
                 <>
                   <div className="w-full bg-gray-200 rounded h-2">
                     <div
                       className={`h-full ${
                         it.state === "error" ? "bg-red-500" : "bg-blue-500"
                       }`}
                       style={{
                         width: `${it.pct}%`,
                         transition: "width .2s",
                       }}
                     />
                   </div>
                   {it.state === "error" && (
                     <div className="text-red-500 text-[10px] break-all">
                       {it.err}
                     </div>
                   )}
                 </>
               )}
             </div>
           ))}
   
           {/* controls */}
           <div className="flex gap-2 pt-2">
             <button
               onClick={addRow}
               disabled={items.length >= MAX_ITEMS}
               className="bg-gray-100 border px-3 py-1 rounded hover:bg-gray-200 text-sm"
             >
               ＋ Add video
             </button>
   
             <button
               onClick={importAll}
               className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded text-sm"
             >
               Import
             </button>
           </div>
   
           <div className="text-[10px] text-gray-400 mt-1">
             You can queue up to {MAX_ITEMS} videos.
           </div>
         </CardContent>
       </Card>
     );
   }
   