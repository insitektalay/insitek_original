import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useEffect, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

export default function TranscriptViewer({ transcriptId, onClose }) {
  const [data, setData]         = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);

  /* ---------- fetch when id changes ---------- */
  useEffect(() => {
    if (!transcriptId) return;

    const fetchOne = async () => {
      setLoading(true);
      try {
        const res = await fetch(`${API_URL}/api/transcripts/${transcriptId}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        setData(json);
        setError(null);
      } catch (err) {
        console.error(err);
        setError("Failed to fetch transcript");
      } finally {
        setLoading(false);
      }
    };

    fetchOne();
  }, [transcriptId]);

  /* ---------- UI states ---------- */
  if (!transcriptId) {
    return (
      <Card className="h-full relative flex flex-col bg-white shadow-md rounded-xl border border-gray-200">
        <CardHeader
          className="relative flex items-center px-4 py-2 bg-grey-100 border-b border-gray-200 text-blue-500 font-medium text-m"
          style={{
            fontFamily:
              'Arial Rounded MT Bold, -apple-system, BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
          }}
        >
          <span>Transcript Viewer</span>
          <button
            onClick={onClose}
            className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl leading-none z-10"
          >
            ×
          </button>
        </CardHeader>
        <CardContent
          className="flex-1 overflow-auto p-4 text-xs text-gray-500"
          style={{
            fontFamily:
              '-apple-system, BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
          }}
        >
          Select a transcript to view.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full relative flex flex-col bg-white shadow-md rounded-xl border border-gray-200">
      <button
        onClick={onClose}
        className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl leading-none z-10"
      >
        ×
      </button>

      <CardHeader
        className="flex items-center px-4 py-2 bg-grey-100 border-b border-gray-200 text-blue-500 font-medium text-m"
        style={{
          fontFamily:
            'Arial Rounded MT Bold, -apple-system, BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
        }}
      >
        {loading ? "Loading…" : data?.title ?? "Transcript Viewer"}
      </CardHeader>

      <CardContent
        className="flex-1 overflow-auto p-4 text-xs text-gray-700 whitespace-pre-wrap"
        style={{
          fontFamily:
            '-apple-system, BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
        }}
      >
        {loading && <div className="text-gray-400 italic">Fetching…</div>}
        {error && <div className="text-red-500">{error}</div>}
        {!loading && !error && data && data.text}
      </CardContent>
    </Card>
  );
}
