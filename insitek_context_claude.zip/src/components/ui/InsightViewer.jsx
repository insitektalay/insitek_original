import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function InsightViewer({ onClose, insight }) {
  if (!insight) {
    return (
      <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
        <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
          <span>Insight Viewer</span>
          <button onClick={onClose} className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl">×</button>
        </CardHeader>
        <CardContent className="flex-1 overflow-auto p-4 text-xs text-gray-500">
          Select an insight from the list to view it.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
        {insight.title}
        <button onClick={onClose} className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl">×</button>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 text-xs text-gray-700 leading-relaxed">
        <div dangerouslySetInnerHTML={{ __html: insight.content }} />
        <div className="flex flex-wrap gap-1 mt-4">
          <span className="bg-green-100 text-green-600 text-[10px] px-2 py-[2px] rounded-full">{insight.channel}</span>
          {insight.tags.map((t)=>(
            <span key={t} className="bg-blue-100 text-blue-600 text-[10px] px-2 py-[2px] rounded-full">{t}</span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
