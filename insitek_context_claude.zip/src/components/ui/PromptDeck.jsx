// src/components/ui/PromptDeck.jsx
import { Card, CardHeader, CardContent } from "@/components/ui/card";

const defaultPrompts = [
  "What percentage of this transcript is rhetoric, opinion, or fact?",
  "Identify and rank the key insights in this transcript by importance.",
  "What's the actual subject of this video based solely on the transcript?",
  "Rate the quality of information presented and explain your rating.",
  "What is the direct answer to the question posed in the video title, without any fluff?",
];

export default function PromptDeck({ onClose, onPromptClick, aiSuggestions = [], onShowSource }) {
  const firePrompt = (prompt) => {
    window.dispatchEvent(new CustomEvent("promptdeck:submit", { detail: prompt }));
    if (onPromptClick) onPromptClick(prompt);
  };

  const handleShowSource = (suggestion, event) => {
    event.stopPropagation(); // Prevent the prompt from firing
    if (onShowSource) {
      onShowSource(suggestion);
    }
  };

  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
        <span>PromptDeck</span>
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >
          ×
        </button>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-2">
        {/* Default prompts */}
        {defaultPrompts.map((p, i) => (
          <button
            key={i}
            className="w-full text-left bg-blue-500 text-white rounded px-2 py-1 hover:bg-blue-600 text-xs"
            onClick={() => firePrompt(p)}
          >
            {p}
          </button>
        ))}

        {/* AI-generated suggestions */}
        {aiSuggestions.length > 0 && (
          <div className="mt-4 space-y-2">
            <div className="text-[10px] uppercase font-bold text-gray-500 mb-1">
              AI Agent Suggestions
            </div>
            {aiSuggestions
              .filter(s => s.trim() && s.length < 220 && !s.toLowerCase().includes("i suggest") && !s.toLowerCase().startsWith("final"))
              .map((s, i) => (
                <div key={`ai-${i}`} className="relative group">
                  <button
                    className="w-full text-left bg-blue-500 text-white rounded px-2 py-1 hover:bg-blue-600 text-xs pr-8"
                    onClick={() => firePrompt(s)}
                  >
                    {s}
                  </button>
                  
                  {/* Source context icon */}
                  <button
                    onClick={(e) => handleShowSource(s, e)}
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 
                             text-white hover:text-yellow-300 opacity-70 hover:opacity-100 
                             transition-opacity p-1"
                    title="Show source context"
                  >
                    <svg 
                      width="12" 
                      height="12" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2"
                    >
                      <circle cx="11" cy="11" r="8"/>
                      <path d="21 21l-4.35-4.35"/>
                    </svg>
                  </button>
                </div>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}