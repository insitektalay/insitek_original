/*  src/components/ui/InsightList.jsx
    -------------------------------------------------------------- */
    import { useEffect, useMemo, useState } from "react";
    import { Card, CardContent, CardHeader } from "@/components/ui/card";
    
    const API_URL =
      import.meta.env.VITE_API_URL ?? "http://localhost:3001";
    
    export default function InsightList({
      onClose,
      onSelectInsight,
      onEditInsight,
    }) {
      /* ─── state ─────────────────────────────────────────── */
      const [rows, setRows]           = useState([]);
      const [allTags, setAllTags]     = useState([]);
      const [allChannels, setAllChannels] = useState([]);
      const [filterTags, setFilterTags]   = useState([]);
      const [filterChannel, setFilterChannel] = useState("");
      const [tagSearch, setTagSearch] = useState("");
    
      /* ─── load rows from API ────────────────────────────── */
      const load = async () => {
        const qs = [
          filterTags.length &&
            `tags=${encodeURIComponent(filterTags.join(","))}`,
          filterChannel &&
            `channel=${encodeURIComponent(filterChannel)}`,
        ]
          .filter(Boolean)
          .join("&");
    
        const data = await fetch(
          `${API_URL}/api/insights${qs ? "?" + qs : ""}`
        ).then((r) => r.json());
    
        setRows(data);
    
        /* collect unique tags + channels */
        const tSet = new Set();
        const cSet = new Set();
        data.forEach((i) => {
          i.tags.forEach((t) => tSet.add(t));
          cSet.add(i.channel);
        });
        setAllTags([...tSet].sort());
        setAllChannels([...cSet].sort());
      };
    
      useEffect(() => { load(); }, [filterTags, filterChannel]);
    
      /* ─── delete with confirmation ─────────────────────── */
      const confirmDelete = async (insight) => {
        const ok = window.confirm(
          `Delete the insight:\n“${insight.title}” ?`
        );
        if (!ok) return;
    
        await fetch(`${API_URL}/api/insights/${insight.id}`, {
          method: "DELETE",
        });
        load(); // refresh list
      };
    
      /* ─── tag helpers ──────────────────────────────────── */
      const toggleTag = (t) =>
        setFilterTags((prev) =>
          prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]
        );
    
      const filteredRows = useMemo(() => {
        if (!tagSearch.trim()) return rows;
        const needle = tagSearch.trim().toLowerCase();
        return rows.filter((r) =>
          r.tags.some((t) => t.toLowerCase().includes(needle))
        );
      }, [rows, tagSearch]);
    
      /* ─── UI ───────────────────────────────────────────── */
      return (
        <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
          <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
            <span>Saved Insights</span>
            <button
              onClick={onClose}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
            >
              ×
            </button>
          </CardHeader>
    
          <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-3">
            {/* search box */}
            <input
              value={tagSearch}
              onChange={(e) => setTagSearch(e.target.value)}
              placeholder="search tags…"
              className="w-full border rounded px-2 py-1"
            />
    
            {/* channel filter */}
            <select
              value={filterChannel}
              onChange={(e) => setFilterChannel(e.target.value)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="">— filter by channel —</option>
              {allChannels.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
    
            {/* tag chips */}
            <div className="flex flex-wrap gap-1">
              {allTags.map((t) => (
                <button
                  key={t}
                  onClick={() => toggleTag(t)}
                  className={`border px-2 py-[2px] text-[10px] rounded-full ${
                    filterTags.includes(t)
                      ? "bg-blue-500 text-white border-blue-500"
                      : "bg-white text-blue-600 border-blue-300"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
    
            {/* insight list */}
            {filteredRows.length === 0 ? (
              <div className="text-gray-400 italic mt-4">No results.</div>
            ) : (
              <ul className="space-y-2 mt-2">
                {filteredRows.map((i) => (
                  <li
                    key={i.id}
                    className="border rounded p-2 hover:bg-gray-100 flex justify-between"
                  >
                    {/* click-to-select area */}
                    <div
                      className="flex-1 cursor-pointer"
                      onClick={() => onSelectInsight(i)}
                    >
                      <div className="font-bold">{i.title}</div>
                      <div className="text-gray-400 text-[10px]">
                        {new Date(i.createdAt).toLocaleString()}
                      </div>
    
                      {/* chips */}
                      <div className="flex flex-wrap gap-1 mt-1">
                        <span className="bg-green-100 text-green-600 text-[10px] px-2 py-[2px] rounded-full">
                          {i.channel}
                        </span>
                        {i.tags.map((t) => (
                          <span
                            key={t}
                            className="bg-blue-100 text-blue-600 text-[10px] px-2 py-[2px] rounded-full"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
    
                    {/* buttons */}
                    <div className="flex flex-col gap-1 ml-2">
                      <button
                        onClick={() => onEditInsight(i)}
                        className="bg-blue-500 text-white text-[10px] rounded px-2"
                      >
                        Edit
                      </button>
    
                      <button
                        onClick={() => confirmDelete(i)}
                        className="bg-red-500 text-white text-[10px] rounded px-2"
                      >
                        Del
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      );
    }
    