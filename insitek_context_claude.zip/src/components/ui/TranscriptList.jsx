import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

/**
 * TranscriptList – channel‑filterable list with styled channel badges
 * Updated to support both YouTube and Podcast transcripts
 */
export default function TranscriptList({ onTranscriptSelected, handleDelete, onClose }) {
  const [rows, setRows]            = useState([]);
  const [loading, setLoading]      = useState(true);
  const [error, setError]          = useState(null);
  const [channelFilter, setFilter] = useState("ALL");

  /* ─── fetch list ────────────────────────────────────────── */
  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${API_URL}/api/transcripts`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      setRows(data);
      setError(null);
    } catch (err) {
      console.error(err);
      setError("Failed to load transcripts");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  /* ─── handle delete ────────────────────────────────────── */
  const confirmDelete = async (transcriptId) => {
    const transcript = rows.find(t => t.id === transcriptId);
    const confirmMessage = `Are you sure you want to delete:\n"${transcript?.title || 'Unknown'}"?`;
    
    if (!window.confirm(confirmMessage)) return;
    
    try {
      const response = await fetch(`${API_URL}/api/transcripts/${transcriptId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete transcript');
      }
      
      // Refresh the list
      load();
    } catch (err) {
      console.error('Delete error:', err);
      alert('Failed to delete transcript');
    }
  };

  /* ─── derived values ────────────────────────────────────── */
  const channels = useMemo(() => {
    const s = new Set(rows.map((t) => t.channel).filter(Boolean));
    return ["ALL", ...Array.from(s).sort((a, b) => a.localeCompare(b))];
  }, [rows]);

  const filteredRows = useMemo(() => (
    channelFilter === "ALL" ? rows : rows.filter((t) => t.channel === channelFilter)
  ), [rows, channelFilter]);

  /* ─── early UI states ───────────────────────────────────── */
  if (loading) {
    return <div className="flex items-center justify-center h-full text-xs text-gray-400 italic">Loading…</div>;
  }
  if (error) {
    return <div className="flex items-center justify-center h-full text-xs text-red-500">{error}</div>;
  }

  /* ─── main render ───────────────────────────────────────── */
  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="flex items-center justify-between gap-2 px-4 py-2 border-b bg-grey-100">
        <span className="font-medium text-blue-500">Transcript List</span>
        <div className="flex items-center gap-2">
          <select
            value={channelFilter}
            onChange={(e) => setFilter(e.target.value)}
            className="text-xs border rounded px-1 py-[2px] bg-white focus:outline-none"
          >
            {channels.map((ch) => (
              <option key={ch} value={ch}>{ch}</option>
            ))}
          </select>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 text-lg leading-none">×</button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 space-y-3 text-xs">
        {filteredRows.length === 0 && (
          <div className="text-gray-400 italic">No transcripts found for this channel.</div>
        )}

        {filteredRows.map((t) => (
          <div key={t.id} className="border rounded p-2 flex justify-between hover:bg-gray-100">
            <div className="flex-1 cursor-pointer" onClick={() => onTranscriptSelected(t)}>
              <div className="font-bold break-words mb-1">{t.title}</div>
              
              {/* Channel badge with different colors for different sources */}
              <div className="flex items-center gap-1 mb-1">
                <span className={`inline-block text-[10px] px-2 py-[2px] rounded-full ${
                  t.source === 'PODCAST' 
                    ? 'bg-purple-100 text-purple-600' 
                    : 'bg-green-100 text-green-600'
                }`}>
                  {t.channel}
                </span>
                
                {/* Source indicator */}
                <span className={`inline-block text-[9px] px-1 py-[1px] rounded-full uppercase font-bold ${
                  t.source === 'PODCAST' 
                    ? 'bg-purple-200 text-purple-700' 
                    : 'bg-red-200 text-red-700'
                }`}>
                  {t.source === 'PODCAST' ? 'POD' : 'YT'}
                </span>
              </div>
              
              <div className="text-[10px] text-gray-600">
                {/* Use publishDate if available, otherwise use importedAt */}
                {new Date(t.publishDate || t.importedAt).toLocaleDateString("en-GB", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric",
                })}
              </div>
            </div>
            <button
              onClick={() => confirmDelete(t.id)}
              className="ml-2 bg-red-500 hover:bg-red-600 text-white text-[10px] rounded px-2 py-[1px]"
            >
              Delete
            </button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}