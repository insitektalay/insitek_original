import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

export default function ChatPanel({ onClose, transcript, onSuggestPrompts, onCaptureInsight }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [insightSuggestions, setInsightSuggestions] = useState([]);

  useEffect(() => {
    setMessages([]);
    setInput('');
    setInsightSuggestions([]);
  }, [transcript?.id]);

  useEffect(() => {
    const handler = (e) => {
      if (typeof e.detail === 'string') {
        setInput(e.detail);
        setTimeout(() => send(e.detail), 0);
      }
    };
    window.addEventListener('promptdeck:submit', handler);
    return () => window.removeEventListener('promptdeck:submit', handler);
  }, [transcript, messages]);

  // 🤖 SMART SELECTIVE INSIGHT EXTRACTION
  const extractSelectiveInsights = async (messageContent, messageIndex) => {
    if (!messageContent || messageContent.length < 200) return;
    
    try {
      const prompt = `Extract 1-3 specific valuable insights from this AI response. Find the most insightful sentences or short paragraphs.

Response:
"${messageContent}"

For each insight found, format as:
INSIGHT_START
[extract the specific insightful text - 1-3 sentences only]
INSIGHT_END
TITLE: [short descriptive title for this insight]
REASON: [why this specific text is valuable]

Only extract text that contains actual insights, analysis, or key information. Skip filler text.`;

      const response = await fetch("http://localhost:8080/completion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          temperature: 0.2,
          n_predict: 400,
          stop: ["Response:", "Extract"]
        })
      });

      if (!response.ok) return;

      const data = await response.json();
      const analysis = data.content || data.completion || "";
      
      // Parse extracted insights
      const insightMatches = analysis.match(/INSIGHT_START\s*(.*?)\s*INSIGHT_END\s*TITLE:\s*(.*?)\s*REASON:\s*(.*?)(?=INSIGHT_START|$)/gs);
      
      if (insightMatches && insightMatches.length > 0) {
        insightMatches.forEach((match, index) => {
          const insightText = match.match(/INSIGHT_START\s*(.*?)\s*INSIGHT_END/s)?.[1]?.trim();
          const title = match.match(/TITLE:\s*(.*?)(?=\s*REASON)/s)?.[1]?.trim();
          const reason = match.match(/REASON:\s*(.*?)$/s)?.[1]?.trim();
          
          if (insightText && insightText.length > 20) {
            const suggestion = {
              messageIndex,
              content: insightText,
              reason: reason || "Contains specific insight",
              suggestedTitle: title || "Extracted Insight",
              keyExcerpt: insightText.length > 100 ? insightText.substring(0, 100) + "..." : insightText,
              type: 'selective',
              timestamp: Date.now() + index
            };
            
            setInsightSuggestions(prev => [...prev, suggestion]);
          }
        });
      }
    } catch (error) {
      console.error("Selective insight extraction error:", error);
    }
  };

  // 📝 KEYWORD-BASED FULL RESPONSE DETECTION (Fallback)
  const detectFullResponseInsight = (messageContent, messageIndex) => {
    const insightKeywords = [
      'summary', 'analysis', 'implications', 'examples', 'explanation', 
      'key points', 'important', 'demonstrates', 'reveals', 'consequences'
    ];
    
    const lowerContent = messageContent.toLowerCase();
    const foundKeywords = insightKeywords.filter(keyword => lowerContent.includes(keyword));
    
    if (foundKeywords.length >= 2 && messageContent.length > 300) {
      const suggestion = {
        messageIndex,
        content: messageContent,
        reason: `Full response contains ${foundKeywords.length} insight indicators`,
        suggestedTitle: "Complete Analysis from Chat",
        keyExcerpt: messageContent.substring(0, 120) + "...",
        type: 'full_response',
        timestamp: Date.now() + 1000 // Ensure it comes after selective insights
      };
      
      setInsightSuggestions(prev => [...prev, suggestion]);
    }
  };

  const renderMsg = (txt) =>
    txt
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .split('\n')
      .map((l, i) => (
        <p key={i} dangerouslySetInnerHTML={{ __html: l }} />
      ));

  const send = async (injectedText = null) => {
    const content = injectedText ?? input.trim();
    if (!content || !transcript) return;

    const userMsg = { role: 'user', content };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setThinking(true);

    const systemPrompt = `You are an expert assistant. Use this transcript as reference:\n${transcript.text}`;
    const prompt = `${systemPrompt}\n\nUser: ${content}\nAI:`;

    try {
      const res = await fetch('http://localhost:8080/completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          temperature: 0.7,
          stop: ['User:', 'AI:'],
          n_predict: 512,
          stream: true,
        }),
      });

      if (!res.ok || !res.body) throw new Error();
      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullText = '';
      
      const newMessageIndex = messages.length + 1;
      setMessages((m) => [...m, { role: 'assistant', content: '' }]);

      let buffer = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const payload = line.slice(6).trim();
          if (payload === '[DONE]') break;

          try {
            const parsed = JSON.parse(payload);
            if (parsed.content) {
              fullText += parsed.content;
              setMessages((m) =>
                m.map((msg, i) =>
                  i === m.length - 1 && msg.role === 'assistant'
                    ? { ...msg, content: fullText }
                    : msg
                )
              );
            }
          } catch {}
        }
      }

      // AI AGENT TRIGGER: suggest prompts after reply
      if (onSuggestPrompts) {
        const chatText = [...messages, userMsg, { role: 'assistant', content: fullText }]
          .map((m) => `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`)
          .join('\n');
        onSuggestPrompts(chatText);
      }

      // 🤖 DUAL INSIGHT DETECTION SYSTEM
      setTimeout(() => {
        // First: Try selective insight extraction
        extractSelectiveInsights(fullText, newMessageIndex);
        
        // Second: Fallback full response detection
        setTimeout(() => {
          detectFullResponseInsight(fullText, newMessageIndex);
        }, 1000);
      }, 500);

    } catch {
      alert('AI request failed.');
    }
    setThinking(false);
  };

  // Manual transfer functions
  const transferLastResponse = () => {
    const lastAIMessage = [...messages].reverse().find(m => m.role === 'assistant');
    if (!lastAIMessage) return alert('No AI response to transfer');

    onCaptureInsight?.({
      content: lastAIMessage.content,
      suggestedTitle: "Full Response from Chat",
      source: 'chat_manual_full',
      timestamp: Date.now()
    });
  };

  const transferSelectedText = () => {
    const selectedText = window.getSelection().toString().trim();
    if (!selectedText) return alert('Please select some text first');
    if (selectedText.length < 20) return alert('Please select more text');

    onCaptureInsight?.({
      content: selectedText,
      suggestedTitle: "Selected Text from Chat",
      source: 'chat_manual_selected',
      timestamp: Date.now()
    });
  };

  // Condensed transfer functions
  const transferCondensedResponse = async (compressionLevel) => {
    const lastAIMessage = [...messages].reverse().find(m => m.role === 'assistant');
    if (!lastAIMessage) return alert('No AI response to condense');

    try {
      const compressionPrompts = {
        0.75: "Condense this response to 75% of its length while keeping all key points:",
        0.5: "Condense this response to 50% of its length, keeping only the most important information:",
        0.25: "Create a very concise summary of this response (25% length), including only the essential points:"
      };

      const prompt = `${compressionPrompts[compressionLevel]}

"${lastAIMessage.content}"

Condensed version:`;

      const response = await fetch("http://localhost:8080/completion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          temperature: 0.3,
          n_predict: Math.floor(lastAIMessage.content.length * compressionLevel * 0.8),
          stop: ["Condensed version:", "Original:", "\n\n"]
        })
      });

      if (!response.ok) throw new Error("Condensing failed");

      const data = await response.json();
      const condensedContent = (data.content || data.completion || "").trim();

      // Clean up any weird characters or artifacts
      const cleanContent = condensedContent
        .replace(/\|+/g, '') // Remove pipe characters
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .replace(/["']/g, '') // Remove extra quotes
        .trim();

      if (cleanContent && cleanContent.length > 20) {
        onCaptureInsight?.({
          content: cleanContent,
          suggestedTitle: `Condensed Insight (${Math.round(compressionLevel * 100)}%)`,
          source: `chat_condensed_${compressionLevel}`,
          timestamp: Date.now()
        });
      } else {
        alert("Failed to generate condensed version");
      }
    } catch (error) {
      console.error("Condensing error:", error);
      alert("Failed to condense response");
    }
  };

  const handleCaptureInsight = (suggestion) => {
    onCaptureInsight?.({
      content: suggestion.content,
      suggestedTitle: suggestion.suggestedTitle,
      source: suggestion.type === 'selective' ? 'chat_smart_selective' : 'chat_smart_full',
      timestamp: suggestion.timestamp
    });
    setInsightSuggestions(prev => prev.filter(s => s.timestamp !== suggestion.timestamp));
  };

  const dismissInsightSuggestion = (timestamp) => {
    setInsightSuggestions(prev => prev.filter(s => s.timestamp !== timestamp));
  };

  const lastAIMessage = [...messages].reverse().find(m => m.role === 'assistant');

  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="relative flex items-center px-4 py-2 bg-grey-100 border-b text-blue-500 font-medium">
        <span>Chat</span>
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl"
        >
          ×
        </button>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-4">
        {!transcript ? (
          <div className="bg-gray-100 p-2 italic rounded">No transcript selected.</div>
        ) : (
          <>
            <div className="bg-gray-100 p-2 rounded text-[11px]">
              <strong>{transcript.title}</strong>
              <span className="ml-2 bg-green-100 text-green-600 px-2 py-[2px] rounded-full">
                {transcript.channel}
              </span>
            </div>
            
            {messages.map((m, i) => (
              <div key={i} className="relative">
                <div className={m.role === 'user' ? 'text-blue-600' : 'text-gray-700'}>
                  <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
                  {m.role === 'assistant' ? renderMsg(m.content) : m.content}
                </div>
                
                {/* 🤖 SMART INSIGHT SUGGESTIONS */}
                {m.role === 'assistant' && insightSuggestions
                  .filter(suggestion => suggestion.messageIndex === i)
                  .map(suggestion => (
                    <div key={suggestion.timestamp} className={`mt-2 p-3 rounded-r border-l-4 ${
                      suggestion.type === 'selective' 
                        ? 'bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-400' 
                        : 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-400'
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className={`text-[11px] font-bold ${
                              suggestion.type === 'selective' 
                                ? 'text-blue-700' 
                                : 'text-yellow-700'
                            }`}>
                              {suggestion.type === 'selective' ? '🎯 SMART EXTRACT' : '📄 FULL RESPONSE'}
                            </span>
                            <span className={`text-[8px] px-1 py-[1px] rounded uppercase font-bold ${
                              suggestion.type === 'selective' 
                                ? 'bg-blue-200 text-blue-800' 
                                : 'bg-yellow-200 text-yellow-800'
                            }`}>
                              {suggestion.type === 'selective' ? 'SELECTIVE' : 'COMPLETE'}
                            </span>
                          </div>
                          <div className={`text-[9px] mb-2 ${
                            suggestion.type === 'selective' ? 'text-blue-600' : 'text-yellow-600'
                          }`}>
                            {suggestion.reason}
                          </div>
                          <div className={`text-[10px] italic mb-3 leading-relaxed p-2 rounded ${
                            suggestion.type === 'selective' 
                              ? 'text-blue-800 bg-blue-100' 
                              : 'text-yellow-800 bg-yellow-100'
                          }`}>
                            "{suggestion.keyExcerpt}"
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleCaptureInsight(suggestion)}
                              className={`text-white text-[10px] px-3 py-1.5 rounded font-bold flex items-center gap-1 ${
                                suggestion.type === 'selective' 
                                  ? 'bg-blue-500 hover:bg-blue-600' 
                                  : 'bg-orange-500 hover:bg-orange-600'
                              }`}
                            >
                              📝 Capture {suggestion.type === 'selective' ? 'Extract' : 'Full'}
                            </button>
                            <button
                              onClick={() => dismissInsightSuggestion(suggestion.timestamp)}
                              className="bg-gray-300 hover:bg-gray-400 text-gray-700 text-[10px] px-2 py-1.5 rounded"
                            >
                              Dismiss
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                }
              </div>
            ))}
            
            {thinking && <div className="italic text-gray-400">AI is thinking…</div>}

            {/* 📝 MANUAL CAPTURE CONTROLS */}
            {lastAIMessage && (
              <div className="border-t pt-3 mt-4">
                <div className="text-[10px] text-gray-600 mb-2 font-bold">📝 MANUAL CAPTURE:</div>
                
                {/* Primary transfer options */}
                <div className="flex gap-2 mb-2">
                  <button
                    onClick={transferLastResponse}
                    className="bg-green-500 hover:bg-green-600 text-white text-[10px] px-3 py-1.5 rounded flex items-center gap-1"
                  >
                    📄 Transfer Full Response
                  </button>
                  <button
                    onClick={transferSelectedText}
                    className="bg-purple-500 hover:bg-purple-600 text-white text-[10px] px-3 py-1.5 rounded flex items-center gap-1"
                  >
                    ✂️ Transfer Selected Text
                  </button>
                </div>
                
                {/* Condensed transfer options */}
                <div className="mb-1">
                  <div className="text-[9px] text-gray-600 mb-1 font-bold">🗜️ CONDENSED VERSIONS:</div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => transferCondensedResponse(0.75)}
                      className="bg-blue-400 hover:bg-blue-500 text-white text-[9px] px-2 py-1 rounded"
                    >
                      75%
                    </button>
                    <button
                      onClick={() => transferCondensedResponse(0.5)}
                      className="bg-blue-500 hover:bg-blue-600 text-white text-[9px] px-2 py-1 rounded"
                    >
                      50%
                    </button>
                    <button
                      onClick={() => transferCondensedResponse(0.25)}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-[9px] px-2 py-1 rounded"
                    >
                      25%
                    </button>
                  </div>
                </div>
                
                <div className="text-[8px] text-gray-500">
                  Manual: Select text + "Selected", "Full" for complete response, or "75%/50%/25%" for AI-condensed versions
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>

      <div className="p-2 border-t flex">
        <input
          className="flex-1 border rounded px-2 py-1 text-xs border-gray-300"
          placeholder="Type your question…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          disabled={!transcript}
        />
        <button
          onClick={() => send()}
          disabled={!transcript || thinking}
          className="ml-2 bg-blue-500 hover:bg-blue-600 text-white rounded text-xs px-4"
        >
          Send
        </button>
      </div>
    </Card>
  );
}