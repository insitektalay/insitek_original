import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const API        = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
const CHUNK_SIZE = 50;
const POLL_MS    = 3000;

/* small util */
const barCls = (s) =>
  s === "error" ? "bg-red-500"
  : s === "done" ? "bg-green-600"
  : s === "busy" ? "bg-blue-500 animate-pulse"
  : "bg-blue-200";

function Row({ n, url, pct, state, err }) {
  return (
    <div className="text-[11px] leading-4 mb-1">
      <span className="font-mono">#{n.toString().padStart(3, "0")}</span>{" "}
      — {url}
      <div className="h-1.5 w-full bg-gray-200 rounded">
        <div className={`h-full ${barCls(state)}`} style={{ width: `${pct}%` }} />
      </div>
      {state === "error" && <div className="text-red-500 truncate">{err}</div>}
    </div>
  );
}

/* main component */
export default function ChannelImportPanel({ onClose }) {
  const [channel, setChannel] = useState("");
  const [meta, setMeta]       = useState(null);
  const [checking, setChk]    = useState(false);
  const [batch, setBatch]     = useState(CHUNK_SIZE);

  const [rows, setRows] = useState([]);
  const timers = useRef({});

  const [cnt, setCnt] = useState({ PENDING: 0, PROCESSING: 0, DONE: 0, ERROR: 0 });

  /* poll counters */
  useEffect(() => {
    const id = setInterval(async () => {
      const r = await fetch(`${API}/api/import-progress`);
      if (r.ok) setCnt(await r.json());
    }, POLL_MS);
    return () => clearInterval(id);
  }, []);

  /* sync row state with counters */
  useEffect(() => {
    setRows((prev) =>
      prev.map((r, i) => {
        if (i < cnt.DONE) return { ...r, state: "done", pct: 100 };
        if (i < cnt.DONE + cnt.ERROR) return { ...r, state: "error", pct: 100 };
        if (i < cnt.DONE + cnt.ERROR + cnt.PROCESSING) return { ...r, state: "busy" };
        return r;
      })
    );
  }, [cnt]);

  /* fake-progress helpers */
  const startFake = (id) => {
    timers.current[id] = setInterval(() => {
      setRows((p) =>
        p.map((r) => (r.id === id && r.state === "busy" ? { ...r, pct: Math.min(r.pct + 3, 96) } : r))
      );
    }, 200);
  };
  const stopFake = (id) => {
    clearInterval(timers.current[id]);
    delete timers.current[id];
  };

  /* ------------ handlers ------------------------------------- */
  async function checkChannel() {
    if (!channel) return;
    setChk(true);
    const r = await fetch(`${API}/api/channel-info`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: channel }),
    });
    if (r.ok) setMeta(await r.json());
    setChk(false);
  }

  async function importBatch() {
    if (!channel) return;
    const r = await fetch(`${API}/api/channel-last-videos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: channel, count: batch }),
    });
    const { videos } = await r.json();

    const slice = videos.slice(0, CHUNK_SIZE);

    const resp = await fetch(`${API}/api/bulk-import`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videos: slice }),
    });
    const { skipped = [] } = await resp.json();

    const list = slice.map((v, i) => ({
      id: Date.now() + i,
      n: i + 1,
      url: v,
      pct: skipped.includes(v) ? 100 : 0,
      state: skipped.includes(v) ? "done" : "busy",
    }));
    setRows(list);
    list.filter((r) => r.state === "busy").forEach((r) => startFake(r.id));
  }

  /* ------------ render --------------------------------------- */
  return (
    <Card className="h-full flex flex-col bg-white shadow-md rounded-xl border">
      <CardHeader className="relative flex items-center px-4 py-2 bg-blue-50 border-b text-blue-600 font-medium">
        <span>Import YouTube Channel</span>
        <button onClick={onClose} className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-xl">
          ×
        </button>
      </CardHeader>

      <CardContent className="flex-1 overflow-auto p-4 text-xs space-y-3">
        <input
          className="w-full border rounded px-2 py-1"
          placeholder="https://youtube.com/@channel/videos"
          value={channel}
          onChange={(e) => setChannel(e.target.value)}
        />

        {meta && (
          <div className="text-[10px] text-gray-500">
            {meta.total} videos — first {meta.firstDate ?? "?"} / last {meta.lastDate ?? "?"}
          </div>
        )}

        <div className="flex items-center space-x-2">
          <button
            onClick={checkChannel}
            disabled={checking}
            className={`text-xs px-3 py-1 rounded text-white ${
              checking ? "bg-blue-300 cursor-not-allowed" : "bg-blue-500 hover:bg-blue-600"
            }`}
          >
            {checking ? "Checking…" : "Check channel"}
          </button>

          <input
            type="number"
            min={1}
            className="w-16 border rounded text-center px-1 py-1"
            value={batch}
            onChange={(e) => setBatch(+e.target.value || 1)}
          />

          <button
            onClick={importBatch}
            className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1 rounded"
          >
            Import
          </button>
        </div>

        <div className="text-[10px] leading-4">
          <div>pending: {cnt.PENDING}</div>
          <div>processing: {cnt.PROCESSING}</div>
          <div>done: {cnt.DONE}</div>
          <div className="text-red-500">error: {cnt.ERROR}</div>
        </div>

        {rows.length > 0 && (
          <div className="border-t pt-2 mt-2 max-h-[55vh] overflow-y-auto pr-1">
            {rows.map((r) => (
              <Row key={r.id} {...r} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
