// src/components/Layout.jsx
import { useState } from "react";

import ImportPanel        from "./ui/ImportPanel";
import ChannelImportPanel from "./ui/ChannelImportPanel";
import PodcastImportPanel from "./ui/PodcastImportPanel";
import TranscriptList     from "./ui/TranscriptList";
import TranscriptViewer   from "./ui/TranscriptViewer";
import SummaryPanel       from "./ui/SummaryPanel";
import ChatPanel          from "./ui/ChatPanel";
import InsightBuilder     from "./ui/InsightBuilder";
import InsightList        from "./ui/InsightList";
import InsightViewer      from "./ui/InsightViewer";
import PromptDeck         from "./ui/PromptDeck";
import SourceContextPanel from "./ui/SourceContextPanel";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

export default function Layout() {
  const [open, setOpen] = useState([]);
  const toggle = (p) =>
    setOpen((prev) =>
      prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]
    );
  const close = (p) => setOpen((prev) => prev.filter((x) => x !== p));

  const [selected, setSelected] = useState(null);
  const [refreshKey, setRefresh] = useState(0);
  const [selectedSuggestion, setSelectedSuggestion] = useState(null);
  const [autoCapturedContent, setAutoCapturedContent] = useState(null);

  const handleSelect = async (payload) => {
    if (!payload) return setSelected(null);
    
    // If it's already a full transcript object with text, use it directly
    if (typeof payload === "object" && payload.text) {
      return setSelected(payload);
    }
    
    // If it's a transcript object but without text, or just an ID, fetch the full transcript
    const transcriptId = typeof payload === "string" ? payload : payload.id;
    
    try {
      const response = await fetch(`${API_URL}/api/transcripts/${transcriptId}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const fullTranscript = await response.json();
      setSelected(fullTranscript);
    } catch (error) {
      console.error("Failed to load full transcript:", error);
      setSelected(null);
    }
  };

  const [importing, setImporting] = useState(false);
  const importYoutube = async (url) => {
    if (!url) return;
    setImporting(true);
    try {
      const res = await fetch(`${API_URL}/api/transcribe-youtube`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Import failed");
      alert(`✅ Imported: ${j.title}`);
      setRefresh((k) => k + 1);
    } catch (e) {
      alert(`❌ ${e.message}`);
    }
    setImporting(false);
  };

  const [aiSuggestions, setAISuggestions] = useState([]);

  // Enhanced AI agent that includes both transcript and chat context
  const generateAISuggestions = async (chatSoFar) => {
    if (!selected || !selected.text) {
      console.warn("No transcript selected for AI suggestions");
      return;
    }

    try {
      const systemPrompt = `Here is the original transcript being discussed:

TRANSCRIPT START:
${selected.text}
TRANSCRIPT END:

And here is the chat conversation about this transcript so far:

CONVERSATION START:
${chatSoFar}
CONVERSATION END:

Now, generate 3 to 5 short, relevant follow-up questions or prompts based on BOTH the transcript content and the conversation so far. 

Focus on:
- Unexplored aspects of the transcript
- Deeper analysis opportunities  
- Specific quotes or segments that haven't been discussed
- Different analytical approaches to the content
- Connections between discussed and undiscussed parts

Only return a numbered list of concise prompts without explanation, hashtags, or filler. Each prompt should be actionable and specific to this transcript.

Suggestions:
1.`;

      const response = await fetch("http://localhost:8080/completion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: systemPrompt,
          temperature: 0.7,
          n_predict: 400,
          stop: ["User:", "AI:", "TRANSCRIPT", "CONVERSATION"],
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      const text = data.content || data.completion || "";
      
      // Parse and filter the suggestions
      const lines = text
        .split("\n")
        .map((l) => l.replace(/^\d+[\).]?\s*/, "").trim()) // Remove numbering
        .filter((l) => l.length > 10 && l.length < 200) // Reasonable length
        .filter((l) => !l.toLowerCase().includes("i suggest")) // No meta-commentary
        .filter((l) => !l.toLowerCase().startsWith("final")) // No final statements
        .filter((l) => l.includes("?") || l.toLowerCase().includes("analyze") || l.toLowerCase().includes("explain") || l.toLowerCase().includes("discuss")) // Ensure they're questions or commands
        .slice(0, 5); // Max 5 suggestions

      console.log("Generated AI suggestions:", lines);
      setAISuggestions(lines);
    } catch (error) {
      console.error("Failed to generate AI suggestions:", error);
      setAISuggestions([]);
    }
  };

  // Handle showing source context for AI suggestions
  const handleShowSource = (suggestion) => {
    setSelectedSuggestion(suggestion);
    if (!open.includes("sourcecontext")) {
      toggle("sourcecontext");
    }
  };

  // Handle auto-captured insights from chat
  const handleCaptureInsight = (capturedContent) => {
    setAutoCapturedContent(capturedContent);
    if (!open.includes("insight")) {
      toggle("insight");
    }
  };

  const panels = [
    ["summary",          "Summary"],
    ["chat",             "Chat"],
    ["insight",          "Insight Editor"],
    ["import",           "Import"],
    ["channelimport",    "Channel Import"],
    ["podcastimport",    "Podcast Import"],
    ["transcriptlist",   "Transcript List"],
    ["transcriptviewer", "Transcript Viewer"],
    ["insightlist",      "Insight List"],
    ["insightviewer",    "Insight Viewer"],
    ["promptdeck",       "PromptDeck"],
    ["sourcecontext",    "Source Context"],
  ];

  return (
    <div className="flex flex-col h-screen bg-white">
      <header className="bg-white p-4 shadow-md flex justify-between items-center">
        <div className="text-blue-500 text-2xl font-bold">Insitek.ai</div>
        <div className="flex flex-wrap gap-2">
          {panels.map(([k, label]) => (
            <button
              key={k}
              onClick={() => toggle(k)}
              className={`text-xs px-3 py-1.5 rounded font-bold border ${
                open.includes(k)
                  ? "bg-blue-500 text-white"
                  : "text-blue-500 border-blue-500"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 flex overflow-x-auto space-x-4 p-4 bg-white">
        {open.includes("summary") && (
          <div className="flex-1 min-w-[300px] max-w-[380px]">
            <SummaryPanel
              transcript={selected}
              onTranscriptSelected={handleSelect}
              onClose={() => close("summary")}
            />
          </div>
        )}

        {open.includes("chat") && (
          <div className="flex-1 min-w-[300px] max-w-[480px]">
            <ChatPanel
              transcript={selected}
              onClose={() => close("chat")}
              onSuggestPrompts={generateAISuggestions}
              onCaptureInsight={handleCaptureInsight}
            />
          </div>
        )}

        {open.includes("import") && (
          <div className="flex-1 min-w-[300px] max-w-[360px]">
            <ImportPanel
              onClose={() => close("import")}
              onDone={() => setRefresh((k) => k + 1)}
              isImporting={importing}
              importYoutube={importYoutube}
            />
          </div>
        )}

        {open.includes("channelimport") && (
          <div className="flex-1 min-w-[300px] max-w-[380px]">
            <ChannelImportPanel
              onClose={() => close("channelimport")}
              onDone={() => setRefresh((k) => k + 1)}
            />
          </div>
        )}

        {open.includes("podcastimport") && (
          <div className="flex-1 min-w-[300px] max-w-[400px]">
            <PodcastImportPanel
              onClose={() => close("podcastimport")}
              onDone={() => setRefresh((k) => k + 1)}
            />
          </div>
        )}

        {open.includes("transcriptlist") && (
          <div className="flex-1 min-w-[300px] max-w-[360px]">
            <TranscriptList
              key={refreshKey}
              onClose={() => close("transcriptlist")}
              onTranscriptSelected={handleSelect}
            />
          </div>
        )}

        {open.includes("transcriptviewer") && (
          <div className="flex-1 min-w-[300px] max-w-[600px]">
            <TranscriptViewer
              transcriptId={selected?.id}
              onClose={() => close("transcriptviewer")}
            />
          </div>
        )}

        {open.includes("insight") && (
          <div className="flex-1 min-w-[300px] max-w-[600px]">
            <InsightBuilder
              transcript={selected}
              onClose={() => {
                close("insight");
                setAutoCapturedContent(null); // Clear auto-captured content when closing
              }}
              autoCapturedContent={autoCapturedContent}
            />
          </div>
        )}

        {open.includes("insightlist") && (
          <div className="flex-1 min-w-[300px] max-w-[360px]">
            <InsightList onClose={() => close("insightlist")} />
          </div>
        )}

        {open.includes("insightviewer") && (
          <div className="flex-1 min-w-[300px] max-w-[600px]">
            <InsightViewer onClose={() => close("insightviewer")} />
          </div>
        )}

        {open.includes("promptdeck") && (
          <div className="flex-1 min-w-[300px] max-w-[380px]">
            <PromptDeck
              transcript={selected}
              onClose={() => close("promptdeck")}
              aiSuggestions={aiSuggestions}
              onShowSource={handleShowSource}
            />
          </div>
        )}

        {open.includes("sourcecontext") && (
          <div className="flex-1 min-w-[300px] max-w-[500px]">
            <SourceContextPanel
              onClose={() => close("sourcecontext")}
              transcript={selected}
              selectedSuggestion={selectedSuggestion}
            />
          </div>
        )}
      </main>

      <footer className="bg-white p-4 text-blue-500 text-center text-xs">
        © 2025 Insitek
      </footer>
    </div>
  );
}