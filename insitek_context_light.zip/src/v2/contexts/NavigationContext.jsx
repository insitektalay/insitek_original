// src/v2/contexts/NavigationContext.jsx
import { createContext, useContext, useState, useCallback, useMemo } from 'react';


const NavigationContext = createContext()

export const useNavigation = () => {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

const pageTabs = {
  Import: ['Youtube video', 'Youtube channel', 'RSS podcast'],
  Transcripts: ['Transcripts', 'Transcript viewer'],
  Chat: ['Chat', 'Summary', 'Prompt Deck', 'Source context'],
  Insights: ['Insight editor', 'Insight list', 'Insight viewer'],
}

export function NavigationProvider({ children }) {
  const [collapsed, setCollapsed] = useState(false)
  const [page, setPage] = useState('Import')
  const [tab, setTab] = useState(pageTabs.Import[0]) // default first tab

  const navigateTo = useCallback((newPage, newTab = null) => {
    setPage(newPage)
    setTab(newTab ?? pageTabs[newPage][0])
  }, [])

  const value = useMemo(() => ({
    collapsed,
    setCollapsed,
    page,
    setPage,
    tab,
    setTab,
    navigateTo,
    pageTabs
  }), [collapsed, page, tab, navigateTo]);
  
  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  );
}

