// src/v2/components/PanelRouter.jsx
import { useNavigation } from '../contexts/NavigationContext'
import { useTranscript } from '../hooks/useTranscript'
import { useImport } from '../hooks/useImport'
import { useAI } from '../hooks/useAI'
import { useInsight } from '../hooks/useInsight'

// Import all panels
import ImportPanel from './ui/ImportPanel'
import ChannelImportPanel from './ui/ChannelImportPanel'
import PodcastImportPanel from './ui/PodcastImportPanel'
import TranscriptList from './ui/TranscriptList'
import TranscriptViewer from './ui/TranscriptViewer'
import SummaryPanel from './ui/SummaryPanel'
import ChatPanel from './ui/ChatPanel'
import PromptDeck from './ui/PromptDeck'
import SourceContextPanel from './ui/SourceContextPanel'
import InsightBuilder from './ui/InsightBuilder'
import InsightList from './ui/InsightList'
import InsightViewer from './ui/InsightViewer'

export default function PanelRouter() {
  const { page, tab, setPage, setTab, navigateTo } = useNavigation()
  const { 
    selected, 
    refreshKey, 
    handleSelect, 
    handleDeleteTranscript, 
    triggerRefresh 
  } = useTranscript()
  const { importing, importYoutube } = useImport()
  const { aiSuggestions, generateAISuggestions } = useAI()
  const { 
    selectedSuggestion, 
    autoCapturedContent, 
    handleShowSource, 
    handleCaptureInsight,
    clearAutoCapturedContent 
  } = useInsight()

  /* Navigation handlers */
  const handleOpenViewer = async (transcriptId) => {
    await handleSelect(transcriptId)
    setPage('Transcripts')
    setTab('Transcript viewer')
  }

  const handleOpenChat = async (transcriptId) => {
    await handleSelect(transcriptId)
    setPage('Chat')
    setTab('Chat')
  }

  /* Wrapper functions */
  const handleImportYoutube = async (url) => {
    await importYoutube(url, triggerRefresh)
  }

  const handleGenerateAISuggestions = async (chatSoFar) => {
    await generateAISuggestions(chatSoFar, selected)
  }

  const handleShowSourceWithNav = (suggestion) => {
    handleShowSource(suggestion, navigateTo)
  }

  const handleCaptureInsightWithNav = (content) => {
    // If we're on the Chat page, don't navigate - just capture the content
    if (page === 'Chat' && tab === 'Chat') {
      handleCaptureInsight(content, () => {}) // Pass empty function instead of navigateTo
    } else {
      handleCaptureInsight(content, navigateTo) // Navigate to Insights page from other pages
    }
  }

  /* Component router */
  const routeKey = `${page}|${tab}`

  switch (routeKey) {
    /* IMPORT */
    case 'Import|Youtube video':
      return (
        <ImportPanel
          onClose={() => {}}
          onDone={triggerRefresh}
          isImporting={importing}
          importYoutube={handleImportYoutube}
        />
      )
    case 'Import|Youtube channel':
      return (
        <ChannelImportPanel
          onClose={() => {}}
          onDone={triggerRefresh}
        />
      )
    case 'Import|RSS podcast':
      return (
        <PodcastImportPanel
          onClose={() => {}}
          onDone={triggerRefresh}
        />
      )

    /* TRANSCRIPTS */
    case 'Transcripts|Transcripts':
      return (
        <TranscriptList
          key={refreshKey}
          onOpenViewer={handleOpenViewer}
          onChat={handleOpenChat}
          onDelete={handleDeleteTranscript}
        />
      )
    case 'Transcripts|Transcript viewer':
      return (
        <TranscriptViewer
          transcriptId={selected?.id}
          onClose={() => {}}
        />
      )

    /* CHAT - TWO COLUMN LAYOUT */
    case 'Chat|Chat':
      return (
        <div className="flex h-full">
          {/* Left Column - Chat Panel */}
          <div className="w-1/2 border-r border-gray-200">
            <ChatPanel
              transcript={selected}
              onClose={() => {}}
              onSuggestPrompts={handleGenerateAISuggestions}
              onCaptureInsight={handleCaptureInsightWithNav}
            />
          </div>
          
          {/* Right Column - Insight Builder */}
          <div className="w-1/2">
            <InsightBuilder
              key="chat-insight-builder"
              transcript={selected}
              autoCapturedContent={autoCapturedContent}
              onClose={clearAutoCapturedContent}
            />
          </div>
        </div>
      )
    case 'Chat|Summary':
      return (
        <SummaryPanel
          transcript={selected}
          onTranscriptSelected={handleSelect}
          onClose={() => {}}
        />
      )
    case 'Chat|Prompt Deck':
      return (
        <PromptDeck
          transcript={selected}
          aiSuggestions={aiSuggestions}
          onShowSource={handleShowSourceWithNav}
          onClose={() => {}}
        />
      )
    case 'Chat|Source context':
      return (
        <SourceContextPanel
          transcript={selected}
          selectedSuggestion={selectedSuggestion}
          onClose={() => {}}
        />
      )

    /* INSIGHTS */
    case 'Insights|Insight list':
      return <InsightList onClose={() => {}} />
    case 'Insights|Insight viewer':
      return <InsightViewer onClose={() => {}} />

    default:
      return <div className="text-sm text-gray-500">Select a tab…</div>
  }
}