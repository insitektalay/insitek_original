import { useEffect, useState, useRef } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Bold from "@tiptap/extension-bold";
import Italic from "@tiptap/extension-italic";
import Heading from "@tiptap/extension-heading";
import BulletList from "@tiptap/extension-bullet-list";
import ListItem from "@tiptap/extension-list-item";
import Link from "@tiptap/extension-link";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

export default function InsightBuilder({ onClose, editingInsight, onSaved, autoCapturedContent }) {
  console.log("🚀 SCRIPT VERSION: V39-SUPER-DEFENSIVE-LOGIC");
  console.log("🔄 COMPONENT RENDER:", {
    timestamp: Date.now(),
    editingInsightId: editingInsight?.id,
    hasAutoCapturedContent: !!autoCapturedContent,
    autoCapturedContentTimestamp: autoCapturedContent?.timestamp
  });

  const [title, setTitle] = useState(editingInsight?.title || "");
  const [channel, setChannel] = useState(editingInsight?.channel || "");
  const [tags, setTags] = useState(editingInsight?.tags || []);
  const [publish, setPublish] = useState(editingInsight?.publishDate || "");
  const [input, setInput] = useState("");
  const [status, setStatus] = useState("");

  const processedContentRef = useRef(new Set());

  const editor = useEditor({
    extensions: [
      StarterKit, Bold, Italic,
      Heading.configure({ levels: [1, 2, 3] }),
      BulletList, ListItem, Link,
    ],
    content: editingInsight?.content || "",
  });

  useEffect(() => {
    if (!editingInsight || !editor) return;
    editor.commands.setContent(editingInsight.content);
    setTitle(editingInsight.title);
    setChannel(editingInsight.channel);
    setTags(editingInsight.tags);
    setPublish(editingInsight.publishDate);
    processedContentRef.current.clear();
  }, [editingInsight, editor]);

  useEffect(() => {
    if (autoCapturedContent && editor) {
      console.log("⚡ V39-SUPER-DEFENSIVE-LOGIC: Processing content");
      
      const contentHash = autoCapturedContent.content.length + '-' + autoCapturedContent.timestamp;
      if (processedContentRef.current.has(contentHash)) {
        console.log("Content already processed, skipping");
        return;
      }
      processedContentRef.current.add(contentHash);

      if (!title && autoCapturedContent.suggestedTitle) {
        setTitle(autoCapturedContent.suggestedTitle);
      }

      const newContent = autoCapturedContent.content;
      
      // Force a delay to let any re-renders settle
      setTimeout(() => {
        const currentText = editor.getText();
        const hasContent = currentText.length > 0;

        console.log("📊 CONTENT CHECK:", {
          "currentText.length": currentText.length,
          "hasContent": hasContent,
          "willAppend": hasContent
        });

        // NUCLEAR OPTION: Always use insertContent with manual positioning
        if (!hasContent) {
          console.log("📝 FIRST INSERT - editor is empty");
          editor.chain().focus().insertContent(`<p>${newContent}</p>`).run();
        } else {
          console.log("➕ APPENDING - moving to end first");
          // Move to absolute end and insert
          const endPos = editor.state.doc.content.size;
          editor.chain()
            .focus()
            .setTextSelection({ from: endPos, to: endPos })
            .insertContent(`<p></p><p>${newContent}</p>`)
            .run();
        }

        setTimeout(() => {
          console.log("🔍 FINAL RESULT:", {
            editorTextLength: editor.getText().length,
            lastPartOfText: editor.getText().slice(-100)
          });
        }, 200);
      }, 100);

      let autoTag = 'auto-captured';
      if (autoCapturedContent.source === 'chat_smart_selective') {
        autoTag = 'smart-extract';
      } else if (autoCapturedContent.source?.includes('condensed')) {
        autoTag = 'condensed';
      }

      if (!tags.includes(autoTag)) {
        setTags(prev => [...prev, autoTag]);
      }

      const sourceLabel = autoCapturedContent.source?.includes('condensed') ?
        'Condensed content captured from chat!' :
        autoCapturedContent.source === 'chat_smart_selective' ?
          'Smart insight extracted from chat!' : 'Content auto-captured from chat!';

      setStatus(sourceLabel);
      setTimeout(() => setStatus(""), 3000);
    }
  }, [autoCapturedContent, editor]);

  const commitInput = () => {
    const add = input.split(",").map(s => s.trim()).filter(Boolean)
      .filter(t => !tags.includes(t));
    if (add.length) setTags([...tags, ...add]);
    setInput("");
  };

  const save = async () => {
    if (!title.trim()) return alert("Title required");
    commitInput();

    const payload = {
      title: title.trim(),
      content: editor?.getHTML() || "",
      tags,
      channel,
      publishDate: publish,
    };

    const url = `${API_URL}/api/insights` + (editingInsight ? `/${editingInsight.id}` : "");
    const method = editingInsight ? "PUT" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error("Failed to save insight");

      setStatus("Saved!");
      setTimeout(() => setStatus(""), 2000);
      onSaved?.();
      onClose();
    } catch (error) {
      console.error("Save error:", error);
      setStatus("Save failed!");
      setTimeout(() => setStatus(""), 2000);
    }
  };

  return (
    <div className="p-4 h-full flex flex-col space-y-3 text-xs overflow-auto relative">
      <div className="space-y-3 flex-1 overflow-auto">
        <div className="space-y-2">
          <div className="flex gap-2">
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="insight title…"
              className="flex-1 border rounded px-3 py-2 text-xs"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          <span className="bg-green-100 text-green-600 text-[10px] px-2 py-[2px] rounded-full">
            {channel}
          </span>
          {publish && (
            <span className="bg-gray-100 text-gray-600 text-[10px] px-2 py-[2px] rounded-full">
              {new Date(publish).toLocaleDateString()}
            </span>
          )}
          {autoCapturedContent && (
            <span className="bg-yellow-100 text-yellow-600 text-[10px] px-2 py-[2px] rounded-full">
              Auto-Captured
            </span>
          )}
        </div>

        <div className="flex flex-wrap gap-1">
          {tags.map(t => (
            <span key={t}
              className="bg-blue-100 text-blue-600 text-[10px] px-2 py-[2px] rounded-full flex items-center gap-1">
              {t}
              <button onClick={() => setTags(tags.filter(x => x !== t))} className="text-[10px]">×</button>
            </span>
          ))}
          <input value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); commitInput(); } }}
            onBlur={commitInput}
            placeholder="add tag…" className="border rounded px-1 text-[10px] w-24" />
        </div>

        <div className="flex-1 overflow-y-auto border rounded">
          <EditorContent
            editor={editor}
            className="px-3 py-2 leading-tight"
            style={{
              minHeight: "300px",
              fontSize: "11px !important"
            }}
          />
        </div>

        <div className="flex justify-between items-center">
          <div className="flex gap-2">
          </div>
          <button onClick={save}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-xs font-bold">
            Save Insight
          </button>
        </div>
        {status && <div className={`text-xs mt-2 ${status.includes('failed') ? 'text-red-600' : 'text-green-600'}`}>{status}</div>}
      </div>
    </div>
  );
}