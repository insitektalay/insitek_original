import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";
const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
export default function TranscriptViewer({ transcriptId, onClose }) {
  const [data, setData]         = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);
  /* ---------- fetch when id changes ---------- */
  useEffect(() => {
    if (!transcriptId) return;
    const fetchOne = async () => {
      setLoading(true);
      try {
        const res = await fetch(`${API_URL}/api/transcripts/${transcriptId}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        setData(json);
        setError(null);
      } catch (err) {
        console.error(err);
        setError("Failed to fetch transcript");
      } finally {
        setLoading(false);
      }
    };
    fetchOne();
  }, [transcriptId]);
  /* ---------- UI states ---------- */
  if (!transcriptId) {
    return (
      <Card className="h-full relative flex flex-col bg-white rounded-xl" style={{ border: '0', borderWidth: '0', borderStyle: 'none', boxShadow: 'none' }}>
        <CardContent
          className="flex-1 overflow-auto p-4 text-xs text-gray-500"
          style={{
            fontFamily:
              '-apple-system, BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',
          }}
        >
          Select a transcript to view.
        </CardContent>
      </Card>
    );
  }
  return (
    <Card className="h-full relative flex flex-col bg-white rounded-xl" style={{ border: '0', borderWidth: '0', borderStyle: 'none', boxShadow: 'none' }}>
      <CardContent
        className="flex-1 overflow-auto p-4 text-xs text-gray-700 whitespace-pre-wrap"
        style={{
          fontFamily:
            '-apple-system, BlinkMacSystemFont,"Segue UI",Roboto,Helvetica,Arial,sans-serif',
        }}
      >
        {loading && <div className="text-gray-400 italic">Fetching…</div>}
        {error && <div className="text-red-500">{error}</div>}
        {!loading && !error && data && data.text}
      </CardContent>
    </Card>
  );
}